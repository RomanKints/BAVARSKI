const FIRST='ПЕРВОРЕЧЕНСКИЙ ЗАВОД', SECOND='ОСЕТИНСКИЙ ЗАВОД';
const seed=['Бойлерное св.','Бойлерное НФ.','Белое','Чех НФ.','Чех св.','Первореченское св.','Первореченское НФ.','Пшеничное','Домашнее','Краснодарское св.','Краснодарское НФ.','Танковое св.','Танковое НФ.','Советское св.','Советское НФ.','Лагер св.','Лагер НФ.','Безалкогольное','Сухумское св.','Сухумское НФ.','Фирменное св.','Эль','Венское'].map(name=>({id:crypto.randomUUID(),name,factory:FIRST})).concat(['Бавария св','Бавария нф','Бавария темная','Бельгийское','Осетия св','Осетия нф','Немецкое','Жигулёвское'].map(name=>({id:crypto.randomUUID(),name,factory:SECOND})));
const defaults={factories:[FIRST,SECOND],products:seed,aliases:{'сухум нф':'Сухумское НФ.','сухум св':'Сухумское св.','лагерь св':'Лагер св.','лагер св':'Лагер св.','лагерь нф':'Лагер НФ.','лагер нф':'Лагер НФ.','фирменное св':'Фирменное св.','фирменное нф':'Фирменное НФ.','танк нф':'Танковое НФ.','танк св':'Танковое св.','чех св':'Чех св.','чех нф':'Чех НФ.','перворечка св':'Первореченское св.','перворечка нф':'Первореченское НФ.','краснодар св':'Краснодарское св.','краснодар нф':'Краснодарское НФ.'},importHistory:[],incomingHistory:[],pending:[],shipments:[],current:[]};
let db=load(),filterFactory='Все',drafts={import:[],incoming:[]},openedPendingId=null,openedShipmentIds=new Set(),stockShareFactory='Все',stockShareSelected=new Set();
let activeVoiceShop='БАВ 1',voiceRecognition=null;
function normalizePendingRowIds(state){for(const order of state?.pending||[]){order.rows=order.rows||[];order.rows.forEach((row,i)=>{if(!row.row_id)row.row_id='legacy-'+String(order.id)+'-'+i})}return state}
function load(){return normalizePendingRowIds(structuredClone(defaults))}
let cloudReady=false,cloudApplying=false,cloudTimer=null,cloudPollTimer=null,cloudLastUpdated='',cloudLastData='',cloudPollBusy=false,cloudStockRefreshBusy=false,cloudRestoreBusy=false,cloudPushBusy=false,cloudSyncEpoch=0,cloudLocalRevision=0,cloudStockValues=new Map(),cloudStockQueue=[],cloudStockBusy=false,cloudStockDrainPromise=null,cloudStockEpoch=0,cloudStockReady=false,cloudStockFetchSeq=0,cloudStockRefreshPending=false,cloudEntityVersions=new Map(),cloudStockChannel=null,cloudOpsChannel=null,cloudMetaBaseline=null,cloudOpQueue=[],cloudOpBusy=false,cloudOwnOps=new Set(),cloudSeenOps=new Set(),cloudPollAgain=false,cloudReplayingOps=false,cloudRealtimeBuffer=[],cloudReplayPromise=null,cloudReplayCursor=0,hydrationPromise=Promise.resolve();
const CLOUD_URL='https://cgrfgrxfbjffqfrroggl.supabase.co';
const CLOUD_KEY='sb_publishable_d0XI-LWOQWTHW4GSCNYfnQ_vU64FQee';
const cloudClient=window.supabase?.createClient(CLOUD_URL,CLOUD_KEY,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:false,storage:window.localStorage,storageKey:'bavarski-supabase-auth'}});
function cloudStockNumber(id){const key=String(id);return cloudStockReady&&cloudStockValues.has(key)?Math.max(0,Number(cloudStockValues.get(key))||0):null}
function cloudStockLabel(id){const value=cloudStockNumber(id);return value===null?'—':String(value)}
function cloudQueueSave(){try{localStorage.setItem('bavarskiStockQueue',JSON.stringify(cloudStockQueue))}catch(e){}}
function cloudQueueLoad(){try{const q=JSON.parse(localStorage.getItem('bavarskiStockQueue')||'[]');if(Array.isArray(q))cloudStockQueue=q.filter(x=>x&&x.opId&&x.id!==undefined&&(x.ensure||Number.isFinite(Number(x.delta))||Number.isFinite(Number(x.setValue))))}catch(e){cloudStockQueue=[]}}
cloudQueueLoad();
function cloudMetaSnapshot(source=db){const copy=JSON.parse(JSON.stringify(source));for(const p of copy.products||[])delete p.stock;return copy}
function cloudSerialize(value){if(Array.isArray(value))return '['+value.map(cloudSerialize).join(',')+']';if(value&&typeof value==='object')return '{'+Object.keys(value).sort().map(k=>JSON.stringify(k)+':'+cloudSerialize(value[k])).join(',')+'}';return JSON.stringify(value)}
function cloudMetaSerialize(value){return cloudSerialize(cloudMetaSnapshot(value))}
function cloudClearEmbeddedStocks(){for(const product of db.products||[])delete product.stock}
function cloudQueueStockEnsure(id,stock=0){const key=String(id);if(cloudStockValues.has(key)||cloudStockQueue.some(x=>x.ensure&&String(x.id)===key))return;cloudStockQueue.push({opId:crypto.randomUUID(),id:key,delta:0,ensure:true,stock:Math.max(0,Number(stock)||0)});cloudStockEpoch++;cloudQueueSave();if(cloudStockReady)cloudDrainStockQueue()}
function cloudQueueStockDelta(id,delta){const key=String(id),amount=Number(delta);if(!cloudStockReady||!cloudStockValues.has(key)||!Number.isFinite(amount)||amount===0)return false;cloudStockQueue.push({opId:crypto.randomUUID(),id:key,delta:amount});cloudStockEpoch++;cloudQueueSave();cloudDrainStockQueue();return true}
function cloudQueueStockSet(id,value){const key=String(id),amount=Math.max(0,Number(value)||0);if(!cloudStockReady||!cloudStockValues.has(key))return false;cloudStockQueue.push({opId:crypto.randomUUID(),id:key,delta:0,setValue:amount});cloudStockEpoch++;cloudQueueSave();cloudDrainStockQueue();return true}
function cloudStockMutationReady(){if(!cloudStockReady){alert('Сначала дождись загрузки остатков из облака.');return false}if(cloudStockBusy||cloudStockQueue.length){alert('Предыдущая операция с остатками ещё синхронизируется. Подожди подтверждения из облака.');return false}return true}
function cloudApplySnapshot(snapshot){const incoming=normalizePendingRowIds(JSON.parse(JSON.stringify(snapshot)));db={...defaults,...incoming};cloudClearEmbeddedStocks();cloudMetaBaseline=cloudMetaSnapshot(db);if(cloudStockReady){for(const p of db.products)cloudQueueStockEnsure(p.id,0);cloudQueueSave()}cloudApplying=true;save();cloudApplying=false;renderCatalog();renderOrders();renderShopButtons();renderHistory('incoming');renderMore()}
function save(){
 if(!cloudApplying){if(cloudReady)cloudLocalRevision++;cloudClearEmbeddedStocks();cloudTrackMetaOps()}
 // Local persistence is an outbox/safety copy only; visible stock is normalized
 // to the last cloud-confirmed value before it is written.
 const payload=JSON.stringify(db),savedAt=Date.now();
 try{localStorage.setItem('bavarskiDB',payload);localStorage.setItem('bavarskiDBSavedAt',String(savedAt))}catch(e){console.warn('BAVARSKI local save:',e)}
 try{const req=indexedDB.open('BAVARSKI_DB',1);req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains('state'))req.result.createObjectStore('state')};req.onsuccess=()=>{const d=req.result;try{const tx=d.transaction('state','readwrite'),store=tx.objectStore('state');store.put(db,'main');store.put(savedAt,'savedAt');tx.oncomplete=()=>d.close();tx.onerror=()=>{console.warn('BAVARSKI IndexedDB save:',tx.error);d.close()}}catch(e){d.close();console.warn('BAVARSKI IndexedDB transaction:',e)}};req.onerror=()=>console.warn('BAVARSKI IndexedDB open:',req.error)}catch(e){console.warn('BAVARSKI IndexedDB unavailable:',e)}
}
function renderCloudData(snapshot){cloudApplySnapshot(snapshot)}
function startCloudPolling(){cloudReady=true;clearInterval(cloudPollTimer);cloudPollTimer=setInterval(()=>{pollCloud()},5000)}
// Metadata changes use the append-only operation log as their source of truth.
// Realtime events are notifications only; poll the authoritative warehouse snapshot to avoid stale event replay.
function cloudEntityVersionKey(collection,entityId){return String(collection)+'::'+String(entityId)}
function cloudReceiveMetaOp(op){
 if(!op?.op_id||cloudSeenOps.has(op.op_id))return;
 if(op.collection==='pending_rows'&&op.action==='upsert'){
  const parent=String(op.payload?.order_id||String(op.entity_id).split('::')[0]);
  if(!db.pending.some(x=>String(x.id)===parent)&&!cloudReplayingOps){
   if(!cloudRealtimeBuffer.some(x=>x.op_id===op.op_id))cloudRealtimeBuffer.push(op);
   cloudReplayOperations().catch(e=>console.warn('BAVARSKI pending row replay:',e));
   return;
  }
 }
 const key=cloudEntityVersionKey(op.collection,op.entity_id),revision=Number(op.entity_revision);
 const known=cloudEntityVersions.get(key)??0;
 // A delayed Realtime event or replay page must never roll an entity backwards.
 if(Number.isFinite(revision)&&revision>0&&revision<=known){cloudSeenOps.add(op.op_id);return}
 cloudSeenOps.add(op.op_id);
 cloudApplyMetaOp(op);
 if(Number.isFinite(revision)&&revision>0)cloudEntityVersions.set(key,revision);
}
function cloudLoadEntityVersions(rows){
 cloudEntityVersions=new Map();
 for(const row of rows||[]){if(row?.collection&&row?.entity_id!==undefined)cloudEntityVersions.set(cloudEntityVersionKey(row.collection,row.entity_id),Number(row.revision)||0)}
}
function cloudApplySyncSnapshot(snapshot){
 if(!snapshot?.data||!Array.isArray(snapshot.data.products))throw new Error('Облачный снимок BAVARSKI v32 не получен');
 cloudLastUpdated=snapshot.updated_at||'';
 cloudReplayCursor=Number(snapshot.operation_cursor)||0;
 cloudSeenOps.clear();
 cloudLoadEntityVersions(snapshot.entity_versions||[]);
 cloudRestoreAuthoritative(snapshot.data);
 cloudLastData=cloudMetaSerialize(snapshot.data);
}
async function cloudFetchSyncSnapshot(){const {data,error}=await cloudClient.rpc('bavarski_get_sync_snapshot');if(error)throw error;cloudApplySyncSnapshot(data);return data}
// Reconcile missed Realtime messages from the append-only operation log.
// The warehouse row is used only as the initial snapshot; it is never polled
// over live edits, so an old snapshot cannot resurrect a deleted order/product.
async function cloudReplayOperations(){
 if(!cloudClient)return;
 if(cloudReplayPromise){cloudPollAgain=true;return cloudReplayPromise}
 cloudReplayPromise=(async()=>{
  cloudReplayingOps=true;
  try{
   do{
    cloudPollAgain=false;
    for(;;){
     const cursor=Number(cloudReplayCursor)||0;
     let request=cloudClient.from('bavarski_operations')
      .select('op_id,collection,action,entity_id,payload,created_at,entity_revision,server_seq')
      .order('server_seq',{ascending:true})
      .range(0,499);
     // Start strictly after the operation sequence captured atomically with the snapshot.
     // The server allocates server_seq only after locking the warehouse row, so
     // a transaction cannot commit later with a sequence below this cursor.
     request=request.gt('server_seq',cursor);
     const {data,error}=await request;
     if(error)throw error;
     const batch=data||[];
     for(const op of batch){
      if(!op?.op_id)continue;
      // Advance even for our own/already-seen operations: the cursor is a log
      // position, not a record of which operations changed this local screen.
      cloudReplayCursor=Math.max(Number(cloudReplayCursor)||0,Number(op.server_seq)||0);
      if(cloudSeenOps.has(op.op_id))continue;
      const queuedAt=cloudOpQueue.findIndex(q=>q.opId===op.op_id);
      if(queuedAt>=0){cloudReceiveMetaOp(op);cloudOpQueue.splice(queuedAt,1);cloudOpQueueSave();continue}
      cloudReceiveMetaOp(op);
     }
     if(batch.length<500)break;
    }
   }while(cloudPollAgain);
  }finally{
   cloudReplayingOps=false;
   const buffered=cloudRealtimeBuffer.splice(0).sort((a,b)=>(Number(a.server_seq)||0)-(Number(b.server_seq)||0));
   for(const op of buffered){
    if(op.collection==='pending_rows'&&op.action==='upsert'){
     const parent=String(op.payload?.order_id||String(op.entity_id).split('::')[0]);
     if(!db.pending.some(x=>String(x.id)===parent)){cloudSeenOps.add(op.op_id);continue}
    }
    cloudReceiveMetaOp(op);
   }
  }
 })();
 try{return await cloudReplayPromise}finally{cloudReplayPromise=null;if(cloudPollAgain){cloudPollAgain=false;cloudReplayOperations().catch(e=>console.warn('BAVARSKI follow-up replay:',e))}}
}
// The warehouse JSON is the current materialized state. Replacing it on startup
// prevents stale local/legacy snapshots from reviving deleted rows. Only locally
// queued, not-yet-confirmed edits are replayed on top of that authoritative state.
function cloudRestoreAuthoritative(remote){
 const incoming=normalizePendingRowIds(JSON.parse(JSON.stringify(remote||{})));
 db={...defaults,...incoming};
 db.factories=Array.isArray(db.factories)?db.factories:[];
 db.products=Array.isArray(db.products)?db.products:[];
 db.pending=Array.isArray(db.pending)?db.pending:[];
 db.shipments=Array.isArray(db.shipments)?db.shipments:[];
 db.importHistory=Array.isArray(db.importHistory)?db.importHistory:[];
 db.incomingHistory=Array.isArray(db.incomingHistory)?db.incomingHistory:[];
 db.aliases=db.aliases&&typeof db.aliases==='object'?db.aliases:{};
 cloudClearEmbeddedStocks();
 cloudMetaBaseline=cloudMetaSnapshot(db);
 cloudApplying=true;save();cloudApplying=false;
 // Do not render warehouse-embedded stock here: bavarski_stock is authoritative.
 // The caller renders only after cloudLoadStock() has completed.
}
function cloudApplyMetaOp(op){
 if(!op||!op.collection)return;
 const c=op.collection,id=String(op.entity_id);
 if(c==='aliases'){
  db.aliases=db.aliases||{};
  if(op.action==='delete')delete db.aliases[id];else db.aliases[id]=op.payload;
 }else if(c==='pending_rows'){
  const data=op.payload||{},orderId=String(data.order_id||id.split('::')[0]),rowId=String(data.row_id||id.split('::')[1]||'');
  // A row event must never recreate an order whose header was deleted.
  // Server-sequenced replay delivers the header before its child rows.
  let order=db.pending.find(x=>String(x.id)===orderId);
  if(order){
   order.rows=order.rows||[];
   const index=order.rows.findIndex((x,i)=>String(x.row_id||('legacy-'+orderId+'-'+i))===rowId);
   if(op.action==='delete'){if(index>=0)order.rows.splice(index,1)}
   else if(data.row){const row=JSON.parse(JSON.stringify(data.row));if(index>=0)order.rows[index]=row;else order.rows.push(row)}
  }
 }else if(['products','pending','shipments','importHistory','incomingHistory','factories'].includes(c)){
  const arr=db[c]||(db[c]=[]),key=x=>cloudOpKey(c,x),index=arr.findIndex(x=>key(x)===id);
  if(op.action==='delete'){if(index>=0)arr.splice(index,1)}
  else if(op.payload!==null&&op.payload!==undefined){
   const value=JSON.parse(JSON.stringify(op.payload));
   if(c==='products')delete value.stock
   if(c==='pending'){const old=index>=0?arr[index]:null;value.rows=Array.isArray(value.rows)?value.rows:(old?.rows||[])}
   if(index>=0)arr[index]=value;else{if(c==='pending')value.rows=value.rows||[];arr.push(value)}
  }
 }
 if(c==='products'&&op.action!=='delete'&&cloudStockReady)cloudQueueStockEnsure(id,0);
 cloudApplying=true;save();cloudApplying=false;
 cloudMetaBaseline=cloudMetaSnapshot(db);
 if(c==='products'||c==='factories')renderCatalog();
 if(c==='pending'||c==='pending_rows'||c==='shipments')renderOrders();
 if(c==='importHistory')renderHistory('import');
 if(c==='incomingHistory')renderHistory('incoming');
 renderMore();
}
function cloudEqual(a,b){return cloudSerialize(a)===cloudSerialize(b)}
function cloudMerge3(base,local,remote,path=''){
 if(cloudEqual(local,base))return remote;
 if(cloudEqual(remote,base))return local;
 if(cloudEqual(local,remote))return local;
 const isObj=x=>x&&typeof x==='object'&&!Array.isArray(x);
 if(Array.isArray(base)||Array.isArray(local)||Array.isArray(remote)){
  const B=Array.isArray(base)?base:[],L=Array.isArray(local)?local:[],R=Array.isArray(remote)?remote:[];
  const keyed=[...B,...L,...R].every(x=>x&&typeof x==='object'&&!Array.isArray(x)&&(x.id!==undefined||x.date!==undefined));
  if(keyed){
   const key=x=>String(x.row_id??x.id??x.date),bm=new Map(B.map(x=>[key(x),x])),lm=new Map(L.map(x=>[key(x),x])),rm=new Map(R.map(x=>[key(x),x]));
   const order=[...R.map(key),...L.map(key),...B.map(key)],seen=new Set(),out=[];
   for(const k of order){
    if(seen.has(k))continue;seen.add(k);
    const hasB=bm.has(k),hasL=lm.has(k),hasR=rm.has(k),bv=bm.get(k),lv=lm.get(k),rv=rm.get(k);
    if(hasB&&!hasL&&!hasR)continue;
    // A deletion on one device must not erase a row that the other device
    // changed after the common base (for example a collected checkbox).
    if(hasB&&!hasL){if(cloudEqual(rv,bv))continue;out.push(rv);continue}
    if(hasB&&!hasR){if(cloudEqual(lv,bv))continue;out.push(lv);continue}
    if(!hasB){if(hasL&&hasR){const v=cloudMerge3(undefined,lv,rv,path+'['+k+']');if(v!==undefined)out.push(v)}else if(hasL)out.push(lv);else if(hasR)out.push(rv);continue}
    const v=cloudMerge3(bv,lv,rv,path+'['+k+']');if(v!==undefined)out.push(v);
   }
   return out;
  }
  // Primitive arrays (for example category names): additions from either device,
  // but a value that existed in the base survives only if both devices retain it.
  const primitive=[...B,...L,...R].every(x=>x===null||['string','number','boolean'].includes(typeof x));
  if(primitive){
   const id=x=>cloudSerialize(x),bm=new Set(B.map(id)),lm=new Set(L.map(id)),rm=new Set(R.map(id));
   const order=[...R,...L,...B],seen=new Set(),out=[];
   for(const x of order){const k=id(x);if(seen.has(k))continue;seen.add(k);if(bm.has(k)){if(lm.has(k)&&rm.has(k))out.push(x)}else if(lm.has(k)||rm.has(k))out.push(x)}
   return out;
  }
  // Non-keyed structured arrays are merged without duplicating identical entries.
  const out=[],seen=new Set();for(const x of [...R,...L]){const k=cloudSerialize(x);if(!seen.has(k)){seen.add(k);out.push(x)}}return out;
 }
 if(isObj(base)||isObj(local)||isObj(remote)){
  const B=isObj(base)?base:{},L=isObj(local)?local:{},R=isObj(remote)?remote:{},keys=new Set([...Object.keys(B),...Object.keys(L),...Object.keys(R)]),out={};
  for(const k of keys){const v=cloudMerge3(B[k],L[k],R[k],path+'.'+k);if(v!==undefined)out[k]=v}return out;
 }
 return local;
}
function cloudMergeLocalAndRemote(remote){
 const localRaw=normalizePendingRowIds(JSON.parse(JSON.stringify(db))),remoteRaw=normalizePendingRowIds(JSON.parse(JSON.stringify(remote)));
 const merged=cloudMerge3(undefined,cloudMetaSnapshot(localRaw),cloudMetaSnapshot(remoteRaw));
 const localProducts=new Map((localRaw.products||[]).map(p=>[String(p.id),p]));
 const remoteProducts=new Map((remoteRaw.products||[]).map(p=>[String(p.id),p]));
 for(const p of merged.products||[])delete p.stock
 cloudLastData=cloudMetaSerialize(remoteRaw);
 cloudApplySnapshot(merged);
 cloudMetaBaseline=cloudMetaSnapshot(remoteRaw);
}
function cloudOpQueueSave(){try{localStorage.setItem('bavarskiMetaOpQueue',JSON.stringify(cloudOpQueue))}catch(e){}}
function cloudOpQueueLoad(){try{const q=JSON.parse(localStorage.getItem('bavarskiMetaOpQueue')||'[]');if(Array.isArray(q))cloudOpQueue=q.filter(x=>x&&x.opId&&x.collection&&x.action&&x.entityId!==undefined)}catch(e){cloudOpQueue=[]}}
cloudOpQueueLoad();
async function cloudReconcileMetaQueue(){
 if(!cloudClient||!cloudOpQueue.length)return;
 const confirmed=new Set(),ids=cloudOpQueue.map(x=>x.opId).filter(Boolean);
 for(let i=0;i<ids.length;i+=100){const batch=ids.slice(i,i+100);const {data,error}=await cloudClient.from('bavarski_operations').select('op_id').in('op_id',batch);if(error)throw error;for(const row of data||[])if(row?.op_id)confirmed.add(row.op_id)}
 cloudOpQueue=cloudOpQueue.filter(x=>!confirmed.has(x.opId));
 // v50 and older outbox rows have no entity revision. Their age/order is unknowable,
 // so replaying them could resurrect deleted data. Preserve them in a local quarantine
 // for recovery, but never send them over the new concurrency protocol.
 const legacy=cloudOpQueue.filter(x=>!Number.isFinite(Number(x.expectedRevision)));
 if(legacy.length){try{const old=JSON.parse(localStorage.getItem('bavarskiMetaLegacyQueue')||'[]');localStorage.setItem('bavarskiMetaLegacyQueue',JSON.stringify([...old,...legacy]))}catch(e){}cloudOpQueue=cloudOpQueue.filter(x=>Number.isFinite(Number(x.expectedRevision)));}
 cloudOpQueueSave();
}
// Establish a local baseline immediately so offline edits enter the durable operation queue too.
cloudMetaBaseline=cloudMetaSnapshot(db);
function cloudOpKey(collection,item){return collection==='factories'?String(item):collection==='shipments'?String(item?.id??'')+'::'+String(item?.date??''):String(item?.id??item?.date??'')}
function cloudEnqueueMeta(collection,action,entityId,payload){
 const id=String(entityId),key=cloudEntityVersionKey(collection,id),base=cloudEntityVersions.get(key)??0;
 const queued=cloudOpQueue.filter(x=>x.collection===collection&&String(x.entityId)===id).length;
 cloudOpQueue.push({opId:crypto.randomUUID(),collection,action,entityId:id,payload:payload===undefined?null:JSON.parse(JSON.stringify(payload)),expectedRevision:base+queued});
 cloudOpQueueSave();
}
function cloudTrackMetaOps(){
 const next=cloudMetaSnapshot(db),prev=cloudMetaBaseline||next;
 // Orders are synchronized as a header plus independent row operations.
 // This prevents two phones checking different rows from overwriting each other.
 const beforeOrders=new Map((prev.pending||[]).map(x=>[String(x.id),x]));
 const afterOrders=new Map((next.pending||[]).map(x=>[String(x.id),x]));
 for(const [id] of beforeOrders)if(!afterOrders.has(id))cloudEnqueueMeta('pending','delete',id,null);
 for(const [id,order] of afterOrders){
  const old=beforeOrders.get(id);
  const header=x=>{const y={...x};delete y.rows;return y};
  if(!old||!cloudEqual(header(old),header(order)))cloudEnqueueMeta('pending','upsert',id,header(order));
  const oldRows=new Map((old?.rows||[]).map((r,i)=>[String(r.row_id||('legacy-'+id+'-'+i)),r]));
  const newRows=new Map((order.rows||[]).map((r,i)=>[String(r.row_id||('legacy-'+id+'-'+i)),r]));
  for(const [rid] of oldRows)if(!newRows.has(rid))cloudEnqueueMeta('pending_rows','delete',id+'::'+rid,{order_id:id,row_id:rid});
  for(const [rid,row] of newRows)if(!oldRows.has(rid)||!cloudEqual(oldRows.get(rid),row))cloudEnqueueMeta('pending_rows','upsert',id+'::'+rid,{order_id:id,row:{...row,row_id:rid}});
 }
 // Histories are first-class append/update/delete collections in the same confirmed operation log.
 for(const collection of ['products','shipments','importHistory','incomingHistory','factories']){
  const before=new Map((prev[collection]||[]).map(x=>[cloudOpKey(collection,x),x]));
  const after=new Map((next[collection]||[]).map(x=>[cloudOpKey(collection,x),x]));
  for(const [id] of before)if(!after.has(id))cloudEnqueueMeta(collection,'delete',id,null);
  for(const [id,value] of after)if(!before.has(id)||!cloudEqual(before.get(id),value))cloudEnqueueMeta(collection,'upsert',id,value);
 }
 const ba=prev.aliases||{},na=next.aliases||{};
 for(const k of Object.keys(ba))if(!(k in na))cloudEnqueueMeta('aliases','delete',k,null);
 for(const k of Object.keys(na))if(!(k in ba)||!cloudEqual(ba[k],na[k]))cloudEnqueueMeta('aliases','upsert',k,na[k]);
 cloudMetaBaseline=next;cloudOpQueueSave();if(cloudOpQueue.length)cloudDrainMetaOps();
}
async function cloudReloadAuthoritative(){
 const snapshot=await cloudFetchSyncSnapshot();
 await cloudLoadStock();
 renderCatalog();renderOrders();renderShopButtons();renderHistory('incoming');renderMore();
 await cloudReplayOperations();
 return snapshot;
}
async function cloudQuarantineConflict(op,serverData){
 const key=cloudEntityVersionKey(op.collection,op.entityId);
 const rejected=cloudOpQueue.filter(x=>cloudEntityVersionKey(x.collection,x.entityId)===key);
 try{const old=JSON.parse(localStorage.getItem('bavarskiMetaConflictQueue')||'[]');localStorage.setItem('bavarskiMetaConflictQueue',JSON.stringify([...old,...rejected.map(x=>({...x,serverRevision:serverData?.current_revision,conflictAt:new Date().toISOString()}))]))}catch(e){}
 cloudOpQueue=cloudOpQueue.filter(x=>cloudEntityVersionKey(x.collection,x.entityId)!==key);cloudOpQueueSave();
 await cloudReloadAuthoritative();
 setCloudStatus('Конфликт на другом телефоне: облачная версия восстановлена. Устаревшее локальное изменение сохранено отдельно и не перезаписало данные.');
}
async function cloudDrainMetaOps(){
 if(!cloudReady||cloudOpBusy||!cloudClient)return;cloudOpBusy=true;
 try{
  while(cloudOpQueue.length){
   const op=cloudOpQueue[0];
   if(!Number.isFinite(Number(op.expectedRevision))){cloudOpQueue.shift();cloudOpQueueSave();continue}
   cloudOwnOps.add(op.opId);setTimeout(()=>cloudOwnOps.delete(op.opId),30000);
   const {data,error}=await cloudClient.rpc('bavarski_apply_operation',{p_op_id:op.opId,p_collection:op.collection,p_action:op.action,p_entity_id:op.entityId,p_payload:op.payload,p_expected_revision:Number(op.expectedRevision)});
   if(error)throw error;
   if(data?.conflict){await cloudQuarantineConflict(op,data);if(cloudOpQueue.length)setTimeout(()=>cloudDrainMetaOps(),0);break}
   if(data?.applied!==true&&data?.duplicate!==true)throw new Error('Облако не подтвердило операцию');
   const revision=Number(data?.revision);
   if(Number.isFinite(revision))cloudEntityVersions.set(cloudEntityVersionKey(op.collection,op.entityId),revision);
   if(data?.updated_at)cloudLastUpdated=data.updated_at;cloudSeenOps.add(op.opId);
   cloudApplyMetaOp({op_id:op.opId,collection:op.collection,action:op.action,entity_id:op.entityId,payload:op.payload,entity_revision:revision});
   cloudOpQueue.shift();cloudOpQueueSave();
  }
  if(!cloudOpQueue.length)setCloudStatus('Облако подключено · все операции синхронизированы');
 }catch(e){
  console.error('BAVARSKI operation sync:',e);const msg=String(e?.message||e);
  if(/bavarski_apply_operation|PGRST202|Could not find the function|client upgrade required/i.test(msg))setCloudStatus('Нужно выполнить SQL-миграцию BAVARSKI v32 в Supabase. Очередь действий сохранена.');
  else setCloudStatus('Ошибка синхронизации действий. Очередь сохранена; повторим отправку.');
  setTimeout(()=>cloudDrainMetaOps(),5000);
 }finally{cloudOpBusy=false}
}
function cloudSubscribeOperations(){
 if(!cloudClient)return;
 if(cloudOpsChannel)cloudClient.removeChannel(cloudOpsChannel);
 cloudOpsChannel=cloudClient.channel('bavarski-operations-live')
  .on('postgres_changes',{event:'INSERT',schema:'public',table:'bavarski_operations'},payload=>{
   const op=payload.new;if(!op?.op_id)return;
   if(cloudOwnOps.has(op.op_id)){cloudSeenOps.add(op.op_id);return}
   // Apply live events immediately; per-entity revisions reject delayed/older events.
   // Events arriving during catch-up are buffered and replayed by server sequence.
   if(cloudReplayingOps){cloudRealtimeBuffer.push(op);return}
   cloudReceiveMetaOp(op);
  })
  .subscribe(status=>{
   if(status==='SUBSCRIBED'){
    cloudReplayOperations().then(()=>{
     if(cloudOpQueue.length)cloudDrainMetaOps();
     setCloudStatus('Облако подключено · изменения передаются в реальном времени');
    }).catch(e=>{
     console.error('BAVARSKI operation replay:',e);
     setCloudStatus('Ошибка получения журнала операций: '+(e.message||'проверь подключение'));
    });
   }else if(status==='CHANNEL_ERROR'||status==='TIMED_OUT'){
    setCloudStatus('Realtime временно недоступен. Изменения останутся в очереди и догрузятся при восстановлении связи.');
   }
  });
 if(cloudOpQueue.length)cloudDrainMetaOps();
}
function cloudApplyStockRow(row){
 if(!row||row.product_id===undefined)return false;
 const id=String(row.product_id),value=Math.max(0,Number(row.stock)||0);
 cloudStockValues.set(id,value);
 cloudStockEpoch++;
 return true;
}
function cloudApplyStockRows(rows){
 const next=new Map();
 for(const row of rows||[]){if(!row||row.product_id===undefined)continue;next.set(String(row.product_id),Math.max(0,Number(row.stock)||0))}
 cloudStockValues=next;cloudStockReady=true;cloudStockEpoch++;
 cloudClearEmbeddedStocks();cloudApplying=true;save();cloudApplying=false;
 renderCatalog();renderOrders();
}
async function cloudLoadStock(){
 if(!cloudClient)throw new Error('Supabase client unavailable');
 let {data,error}=await cloudClient.from('bavarski_stock').select('product_id,stock,last_op_id,updated_at');if(error)throw error;
 const present=new Set((data||[]).map(row=>String(row.product_id)));
 const missing=(db.products||[]).filter(p=>!present.has(String(p.id))).map(p=>{const queued=cloudStockQueue.find(x=>x.ensure&&String(x.id)===String(p.id));return {product_id:String(p.id),stock:Math.max(0,Number(queued?.stock??queued?.delta)||0)}});
 if(missing.length){const ensured=await cloudClient.rpc('bavarski_stock_ensure_many',{p_items:missing});if(ensured.error)throw ensured.error;const reread=await cloudClient.from('bavarski_stock').select('product_id,stock,last_op_id,updated_at');if(reread.error)throw reread.error;data=reread.data||[]}
 cloudApplyStockRows(data);
 if(!cloudStockChannel)cloudStockChannel=cloudClient.channel('bavarski-stock-live-v59').on('postgres_changes',{event:'*',schema:'public',table:'bavarski_stock'},()=>{
  // Realtime is only a wake-up signal. Read the authoritative current table;
  // never trust an event payload that may arrive out of order.
  cloudRefreshStockValues().catch(e=>console.warn('BAVARSKI Realtime stock refresh:',e));
 }).subscribe();
}
async function cloudRefreshStockValues(){
 if(!cloudClient)return;
 if(cloudStockBusy){cloudStockRefreshPending=true;return}
 const request=++cloudStockFetchSeq;
 const {data,error}=await cloudClient.from('bavarski_stock').select('product_id,stock,last_op_id,updated_at');
 if(error)throw error;
 if(request!==cloudStockFetchSeq||cloudStockBusy)return;
 cloudApplyStockRows(data||[]);
}
async function cloudForceReloadStock(){
 if(!cloudClient)throw new Error('Supabase client unavailable');
 await cloudRefreshStockValues();
}
async function cloudDrainStockQueue(){
 if(!cloudStockReady||!cloudClient)return;if(cloudStockDrainPromise)return cloudStockDrainPromise;
 cloudStockDrainPromise=(async()=>{
  cloudStockBusy=true;
  try{
   while(cloudStockQueue.length){
    const op=cloudStockQueue[0];
    if(op.ensure){const {error}=await cloudClient.rpc('bavarski_stock_ensure_many',{p_items:[{product_id:String(op.id),stock:Math.max(0,Number(op.stock??op.delta)||0)}]});if(error)throw error}
    else{const {error}=await cloudClient.rpc('bavarski_stock_apply',{p_op_id:op.opId,p_product_id:String(op.id),p_delta:Number(op.delta)||0,p_set_value:op.setValue===undefined?null:Math.max(0,Number(op.setValue)||0)});if(error)throw error}
    // Remove an outbox entry only after reading the current row with its server timestamp.
    const q=await cloudClient.from('bavarski_stock').select('product_id,stock,last_op_id,updated_at').eq('product_id',String(op.id)).maybeSingle();if(q.error)throw q.error;if(!q.data)throw new Error('Облако не вернуло подтверждённый остаток');
    cloudStockFetchSeq++;cloudApplyStockRow(q.data);cloudStockQueue.shift();cloudQueueSave();cloudClearEmbeddedStocks();cloudApplying=true;save();cloudApplying=false;renderCatalog();renderOrders();
   }
   const request=++cloudStockFetchSeq;const {data,error}=await cloudClient.from('bavarski_stock').select('product_id,stock,last_op_id,updated_at');if(error)throw error;if(request===cloudStockFetchSeq&&!cloudStockQueue.length)cloudApplyStockRows(data);
   setCloudStatus('Облако подключено · остатки синхронизированы');
  }catch(e){console.error('BAVARSKI stock sync:',e);setCloudStatus('Ошибка синхронизации остатков. Операция сохранена в очереди; повторим отправку.');setTimeout(()=>cloudDrainStockQueue(),3000)}
  finally{cloudStockBusy=false;if(cloudStockRefreshPending){cloudStockRefreshPending=false;setTimeout(()=>cloudRefreshStockValues().catch(e=>console.warn('BAVARSKI deferred stock refresh:',e)),0)}}
 })();
 try{return await cloudStockDrainPromise}finally{cloudStockDrainPromise=null;if(cloudStockQueue.length)setTimeout(()=>cloudDrainStockQueue(),0)}
}
async function pollCloud(){
 if(!cloudReady||!cloudClient)return;
 // Never wait for the metadata journal before refreshing the stock display.
 if(!cloudStockRefreshBusy){
  cloudStockRefreshBusy=true;
  try{await cloudRefreshStockValues()}
  catch(e){console.warn('BAVARSKI stock display refresh:',e);setCloudStatus('Не удалось обновить отображение остатков: '+(e?.message||'повторим автоматически'))}
  finally{cloudStockRefreshBusy=false}
 }
 // Metadata replay remains its existing process and cannot block stock polling.
 if(!cloudPollBusy){
  cloudPollBusy=true;
  cloudReplayOperations().catch(e=>{console.warn('BAVARSKI metadata catch-up:',e);setCloudStatus('Не удалось обновить журнал операций: '+(e?.message||'повторим автоматически'))}).finally(()=>{cloudPollBusy=false});
 }
}
function setCloudStatus(message){const text=String(message||'');const ok=/все операции синхронизированы|остатки синхронизированы|облако подключено|подключено · журнал и остатки проверены|изменения передаются в реальном времени|единый снимок и версии подтверждены|версии записей проверены/i.test(text);const bad=/ошибка|не удалось|не подключено|недоступ|не доступно|не загрузил|pin не подошёл|нужно выполнить sql|конфликт на другом телефоне/i.test(text);const state=bad?'error':ok?'ready':'syncing';const short=bad?'ОШИБКА':ok?'ОБЛАКО ОК':/провер|подключаем/i.test(text)?'ПРОВЕРКА':'СИНХР.';for(const id of ['globalCloudStatus','cloudStatus']){const el=document.getElementById(id);if(el){el.textContent=id==='globalCloudStatus'?short:text;el.title=text;el.classList.remove('cloud-ready','cloud-syncing','cloud-error');el.classList.add('cloud-'+state)}}}
async function restoreCloud(){
 if(!cloudClient||cloudReady||cloudRestoreBusy)return;cloudRestoreBusy=true;
 try{
  await hydrationPromise;setCloudStatus('Проверяем сохранённое подключение…');
  const {data:sessionData,error:sessionError}=await cloudClient.auth.getSession();if(sessionError)throw sessionError;
  if(!sessionData?.session){setCloudStatus('Облако не подключено. Нажми «Подключить общую базу» один раз.');return}
  const snapshot=await cloudFetchSyncSnapshot();
  await cloudReconcileMetaQueue();await cloudLoadStock();
  renderCatalog();renderOrders();renderShopButtons();renderHistory('incoming');renderMore();
  startCloudPolling();cloudSubscribeOperations();await cloudReplayOperations();
  if(cloudOpQueue.length)await cloudDrainMetaOps();if(cloudStockQueue.length)await cloudDrainStockQueue();
  await cloudReplayOperations();await cloudForceReloadStock();
  setCloudStatus('Облако подключено · единый снимок и версии подтверждены');
 }catch(e){console.warn('BAVARSKI cloud restore:',e);const msg=String(e?.message||e);setCloudStatus(/bavarski_get_sync_snapshot|PGRST202|Could not find the function/i.test(msg)?'Нужно выполнить SQL-миграцию BAVARSKI v32 в Supabase.':'Не удалось восстановить облако: '+(e.message||'проверь интернет'))}
 finally{cloudRestoreBusy=false}
}
async function connectCloud(){
 await hydrationPromise;const pin=document.getElementById('cloudPin')?.value.trim()||'';if(!/^\d{4}$/.test(pin))return alert('Введи свой четырёхзначный PIN');if(!cloudClient)return alert('Не загрузился модуль облака. Проверь интернет и обнови страницу.');
 const btn=document.getElementById('cloudConnectBtn');if(btn)btn.disabled=true;setCloudStatus('Подключаемся…');
 try{
  let {data:sessionData,error:sessionError}=await cloudClient.auth.getSession();if(sessionError)throw sessionError;if(!sessionData.session){const signed=await cloudClient.auth.signInAnonymously();if(signed.error)throw signed.error}
  const joined=await cloudClient.rpc('bavarski_join',{p_pin:pin});if(joined.error)throw joined.error;if(joined.data!==true){setCloudStatus('PIN не подошёл. Проверь и попробуй ещё раз.');return alert('Неверный PIN')}
  const snapshot=await cloudFetchSyncSnapshot();
  await cloudReconcileMetaQueue();await cloudLoadStock();renderCatalog();renderOrders();renderShopButtons();renderHistory('incoming');renderMore();
  startCloudPolling();cloudSubscribeOperations();await cloudReplayOperations();if(cloudOpQueue.length)await cloudDrainMetaOps();if(cloudStockQueue.length)await cloudDrainStockQueue();await cloudReplayOperations();await cloudForceReloadStock();
  document.getElementById('cloudPin').value='';setCloudStatus('Подключено · версии записей проверены, изменения передаются в реальном времени');
 }catch(e){console.error('BAVARSKI cloud connect:',e);cloudApplying=false;const msg=String(e?.message||e);setCloudStatus(/bavarski_get_sync_snapshot|PGRST202|Could not find the function/i.test(msg)?'Нужно выполнить SQL-миграцию BAVARSKI v32 в Supabase.':'Ошибка подключения: '+(e.message||'проверь интернет и настройки'));alert('Не удалось подключиться: '+(e.message||'неизвестная ошибка'))}
 finally{if(btn)btn.disabled=false}
}
async function hydrate(){
 // V51: localStorage/IndexedDB are never read to hydrate application data.
 // The first visible business state is rendered only after the cloud snapshot loads.
 db=normalizePendingRowIds(structuredClone(defaults));
 cloudClearEmbeddedStocks();
 cloudMetaBaseline=cloudMetaSnapshot(db);
}
function show(id){document.querySelectorAll('.screen').forEach(x=>x.classList.toggle('active',x.id===id));document.querySelectorAll('.tabbar button').forEach(x=>x.classList.toggle('active',x.dataset.tab===id));if(id==='catalog')renderCatalog();if(id==='orders')renderOrders();if(id==='incoming')renderHistory('incoming');if(id==='more')renderMore();if(id==='orders')renderShopButtons();if(id==='voice')renderVoiceShopButtons()}
function norm(s){return (s||'').toLowerCase().replace(/ё/g,'е').replace(/[^а-яa-z0-9 ]/gi,' ').replace(/\s+/g,' ').trim()}
function lev(a,b){let v=Array.from({length:b.length+1},(_,i)=>i);for(let i=1;i<=a.length;i++){let p=v[0];v[0]=i;for(let j=1;j<=b.length;j++){let t=v[j];v[j]=Math.min(v[j]+1,v[j-1]+1,p+(a[i-1]===b[j-1]?0:1));p=t}}return v[b.length]}
function matchProduct(raw){let n=norm(raw);if(db.aliases[n]){const p=db.products.find(p=>p.name===db.aliases[n]);if(p)return {product:p,candidates:[p]}}let exact=db.products.find(p=>norm(p.name)===n);if(exact)return {product:exact,candidates:[exact]};let scored=db.products.map(p=>({p,score:1-lev(n,norm(p.name))/Math.max(n.length,norm(p.name).length,1)})).sort((a,b)=>b.score-a.score);let top=scored.filter(x=>x.score>=Math.max(.43,scored[0].score-.17)).slice(0,4);return {product:scored[0]?.score>=.72?scored[0].p:null,candidates:top.map(x=>x.p)}}
function parseLines(text,mode){return text.split(/\n|\r/).map(line=>line.trim()).filter(Boolean).map(line=>{let checked=/☑|✓|✔|\[\s*x\s*\]/i.test(line),unchecked=/☐|□|\[\s*\]/i.test(line);let marked=checked||unchecked;let clean=line.replace(/☑|☐|□|✓|✔|\[\s*x\s*\]|\[\s*\]/gi,' ').replace(/^\s*[-*•]\s*/, '').trim();let qtyMatch=clean.match(/(?:[xх×]\s*)?(\d+)\s*(?:шт\.?|кег\.?|ящ\.?|л\.?\b)?\s*$/i);let qty=qtyMatch?Math.max(1,parseInt(qtyMatch[1],10)):1;let name=qtyMatch?clean.slice(0,qtyMatch.index).replace(/[—–,:;\-]+$/,'').trim():clean;name=name.replace(/\s*[xх×]\s*$/,'').trim();if(!name)return null;let m=matchProduct(name);return {line,name,qty,checked:mode==='import'?(marked?checked:false):true,selected:m.product?.name||'',candidates:m.candidates.map(p=>p.name)}}).filter(Boolean)}
function parseText(mode){let text=document.getElementById(mode==='import'?'importText':'incomingText').value;let rows=parseLines(text,mode);drafts[mode]=rows;let box=document.getElementById(mode==='import'?'importRows':'incomingRows');box.classList.remove('hidden');box.innerHTML=`<div class="row between"><b>Проверка распознавания</b><span class="badge">${rows.length} строк</span></div>`+(rows.length?rows.map((r,i)=>`<div class="itemline"><div><b>${esc(r.name)}</b><div class="tiny">${esc(r.line)} · ${r.qty} шт.</div>${mode==='import'?`<label class="tiny"><input type="checkbox" ${r.checked?'checked':''} onchange="toggleChecked('${mode}',${i},this.checked)"> Списать</label>`:''}</div><div>${r.candidates.length?`<select class="field" onchange="selectMatch('${mode}',${i},this.value)"><option value="">${r.selected?'✓ '+esc(r.selected):'Выбрать товар'}</option>${r.candidates.map(n=>`<option value="${esc(n)}">${esc(n)}</option>`).join('')}</select>`:`<span class="badge">Нет совпадения</span>`}</div></div>`).join(''):`<div class="empty">Строки не найдены</div>`)+`<button class="btn" onclick="applyParsed('${mode}')">${mode==='import'?'Подтвердить списание':'Оприходовать товар'}</button>`;let status=document.getElementById(mode==='import'?'importStatus':'incomingStatus');if(status)status.textContent='Проверь названия и количество. Если совпадение неверное — выбери правильный товар.'}
function toggleChecked(mode,i,v){drafts[mode][i].checked=v}function selectMatch(mode,i,v){let r=drafts[mode][i];if(!v)return;r.selected=v;db.aliases[norm(r.name)]=v;save()}
function applyParsed(mode){if(!cloudStockMutationReady())return;let rows=drafts[mode],added=[],skipped=[],changes=[],stockOps=[],projected=new Map();for(const r of rows){if(mode==='import'&&!r.checked)continue;let p=db.products.find(p=>p.name===r.selected);if(!p){skipped.push(`${r.name} (${r.qty})`);continue}let current=projected.has(String(p.id))?projected.get(String(p.id)):cloudStockNumber(p.id);if(current===null){skipped.push(`${r.name} (остаток не загружен)`);continue}if(mode==='import'){const actual=Math.min(current,Number(r.qty)||0);if(actual>0){stockOps.push({id:p.id,delta:-actual});projected.set(String(p.id),current-actual)}added.push(`${p.name} −${actual}`);changes.push({productId:String(p.id),name:p.name,qty:actual})}else{const qty=Number(r.qty)||0;if(qty>0){stockOps.push({id:p.id,delta:qty});projected.set(String(p.id),current+qty)}added.push(`${p.name} +${qty}`);changes.push({productId:String(p.id),name:p.name,qty})}}for(const op of stockOps)cloudQueueStockDelta(op.id,op.delta);let entry={id:crypto.randomUUID(),date:new Date().toISOString(),done:added,skipped,...(mode==='incoming'?{changes}:{})};(mode==='import'?db.importHistory:db.incomingHistory).unshift(entry);save();drafts[mode]=[];document.getElementById(mode==='import'?'importRows':'incomingRows').classList.add('hidden');document.getElementById(mode==='import'?'importText':'incomingText').value='';let status=document.getElementById(mode==='import'?'importStatus':'incomingStatus');if(status)status.textContent=`Готово. Обработано: ${added.length}, пропущено: ${skipped.length}`;renderHistory(mode);renderCatalog()}
function undoLastIncoming(){if(!cloudStockMutationReady())return;const entry=db.incomingHistory?.[0];if(!entry)return alert('Нет прихода для отмены');let changes=Array.isArray(entry.changes)?entry.changes:null;if(!changes){changes=[];for(const line of entry.done||[]){const m=String(line).match(/^(.*) \+(\d+(?:[.,]\d+)?)$/);if(!m)return alert('Эту старую запись нельзя безопасно отменить автоматически. Удали её вручную после проверки остатков.');const product=db.products.find(p=>p.name===m[1]);if(!product)return alert(`Товар «${m[1]}» уже отсутствует в каталоге. Отмена остановлена.`);changes.push({productId:String(product.id),name:product.name,qty:Number(m[2].replace(',','.'))})}}if(!changes.length)return alert('В этой записи нет добавленных товаров');if(!confirm(`Отменить последний приход от ${new Date(entry.date).toLocaleString('ru-RU')}?\nОстатки будут уменьшены на количество из этой записи.`))return;const ops=[];for(const c of changes){const product=db.products.find(p=>String(p.id)===String(c.productId));if(!product)return alert(`Товар «${c.name}» не найден. Остатки не изменены.`);const current=cloudStockNumber(c.productId);if(current===null)return alert(`Облачный остаток товара «${c.name}» не загружен.`);const qty=Math.min(current,Number(c.qty)||0);if(qty>0)ops.push({id:c.productId,delta:-qty})}for(const op of ops)cloudQueueStockDelta(op.id,op.delta);db.incomingHistory.shift();save();renderHistory('incoming');renderCatalog();alert('Отмена прихода отправлена в облако. Остатки обновятся после подтверждения Supabase.')}

function renderHistory(mode){
 let arr=mode==='import'?db.importHistory:db.incomingHistory;let id=mode==='import'?'importHistory':'incomingHistory';
 const undo=mode==='incoming'?'<button class="btn small danger" onclick="undoLastIncoming()" '+(arr.length?'':'disabled')+'>Отменить последний приход</button>':'';
 document.getElementById(id).innerHTML='<div class="row between"><b>История операций</b></div>'+undo+(arr.length?arr.map((e,i)=>`<details class="history-entry compact-history"><summary class="shipment-summary"><b>${mode==='import'?'Списание':'Приход'}</b><span class="tiny">${new Date(e.date).toLocaleString('ru-RU')}</span><span class="pending-summary-arrow">⌄</span></summary><div class="history-lines">${esc((e.done||[]).join('\n')||'Нет изменений')}</div>${e.skipped?.length?`<div class="history-lines" style="color:#ff9a9a">Пропущено:\n${esc(e.skipped.join('\n'))}</div>`:''}<div class="history-actions"><button class="btn small danger" onclick="deleteHistoryEntry('${mode}',${i})">Удалить запись</button></div></details>`).join(''):'<div class="empty">История пока пуста</div>')
}
function deleteHistoryEntry(mode,index){let arr=mode==='import'?db.importHistory:mode==='incoming'?db.incomingHistory:db.shipments;if(!arr?.[index])return;if(confirm('Удалить эту запись истории?')){arr.splice(index,1);save();if(mode==='import'||mode==='incoming')renderHistory(mode);else renderOrders();renderMore()}}
function clearHistory(mode){let arr=mode==='import'?db.importHistory:mode==='incoming'?db.incomingHistory:db.shipments;if(!arr?.length)return;if(confirm('Удалить всю эту историю?')){arr.length=0;save();if(mode==='import'||mode==='incoming')renderHistory(mode);else renderOrders();renderMore()}}
async function shareText(text,title='BAVARSKI'){if(!text.trim())return alert('Пока нечем делиться');try{if(navigator.share){await navigator.share({title,text});return}}catch(e){if(e?.name==='AbortError')return}try{if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(text);alert('Список скопирован. Теперь можешь отправить его куда нужно.');return}}catch(e){}prompt('Скопируй список:',text)}
function shareStock(){stockShareFactory=filterFactory!=='Все'?filterFactory:'Все';stockShareSelected=new Set();renderStockShareModal();document.getElementById('stockShareModal').classList.remove('hidden')}
function closeStockShare(){document.getElementById('stockShareModal').classList.add('hidden')}
function renderStockShareModal(){let factories=[...new Set([...(db.factories||[]),...db.products.map(p=>p.factory).filter(Boolean)])];let select=document.getElementById('stockShareFactory');select.innerHTML=['Все',...factories].map(f=>`<option value="${esc(f)}" ${stockShareFactory===f?'selected':''}>${esc(f==='Все'?'Все категории':f)}</option>`).join('');let products=db.products.filter(p=>stockShareFactory==='Все'||p.factory===stockShareFactory).sort((a,b)=>a.name.localeCompare(b.name,'ru'));document.getElementById('stockShareList').innerHTML=products.length?products.map(p=>`<label class="stock-share-row"><input type="checkbox" ${stockShareSelected.has(p.id)?'checked':''} onchange="toggleStockShare('${p.id}',this.checked)"><span class="stock-share-name"><b>${esc(p.name)}</b><small>${esc(p.factory)}</small></span><strong>${cloudStockLabel(p.id)} шт.</strong></label>`).join(''):'<div class="empty">В этой категории товаров нет</div>';let count=products.filter(p=>stockShareSelected.has(p.id)).length;document.getElementById('stockShareCount').textContent=`Выбрано: ${count}`;}
function changeStockShareFactory(value){stockShareFactory=value;stockShareSelected=new Set();renderStockShareModal()}
function toggleStockShare(id,checked){if(checked)stockShareSelected.add(id);else stockShareSelected.delete(id);document.getElementById('stockShareCount').textContent=`Выбрано: ${stockShareSelected.size}`}
function shareSelectedStock(){let source=db.products.filter(p=>stockShareFactory==='Все'||p.factory===stockShareFactory);if(!source.length)return alert('В выбранной категории нет товаров');/* Merge case-only duplicate catalogue rows for the outgoing stock list. Keep the greatest known stock rather than summing duplicate records, and preserve selection if any duplicate row was checked. */let grouped=new Map();for(const p of source){const key=norm(p.factory)+'::'+norm(p.name);let g=grouped.get(key);if(!g){g={factory:p.factory,name:p.name,stock:cloudStockNumber(p.id),ids:[p.id]};grouped.set(key,g)}else{g.ids.push(p.id);g.stock=g.stock===null?cloudStockNumber(p.id):cloudStockNumber(p.id)===null?g.stock:Math.max(g.stock,cloudStockNumber(p.id));if(g.name===g.name.toUpperCase()&&p.name!==p.name.toUpperCase())g.name=p.name}}let products=[...grouped.values()].sort((a,b)=>a.factory.localeCompare(b.factory,'ru')||a.name.localeCompare(b.name,'ru'));let date=new Date().toLocaleDateString('ru-RU');let lines=[`ОСТАТКИ, ${date}`,''];if(stockShareFactory==='Все'){let last='';for(let p of products){if(p.factory!==last){last=p.factory;lines.push(last)}lines.push(`${p.ids.some(id=>stockShareSelected.has(id))?'☑ ':'\u00A0\u00A0\u00A0\u00A0'}${p.name} — ${p.stock===null?'—':p.stock} шт.`)}}else{lines.push(stockShareFactory);lines.push('');for(let p of products)lines.push(`${p.ids.some(id=>stockShareSelected.has(id))?'☑ ':'\u00A0\u00A0\u00A0\u00A0'}${p.name} — ${p.stock===null?'—':p.stock} шт.`)}closeStockShare();shareText(lines.join('\n'),'Остатки BAVARSKI')}
function setFactory(f,el){filterFactory=f;document.querySelectorAll('#factoryFilters .pill').forEach(x=>x.classList.remove('active'));el.classList.add('active');renderCatalog()}
function setFactoryIndex(i,el){let choices=['Все',...(db.factories||[])];setFactory(choices[i]||'Все',el)}
function renderCatalog(){db.factories=[...new Set([...(db.factories||[]),...db.products.map(p=>p.factory).filter(Boolean)])];let filters=document.getElementById('factoryFilters');if(filters){let choices=['Все',...db.factories];filters.innerHTML=choices.map((f,i)=>`<button class="pill ${filterFactory===f?'active':''}" onclick="setFactoryIndex(${i},this)">${esc(f==='Все'?'Все':f.replace(/\s+ЗАВОД$/i,'').replace(/\s+завод$/i,''))}</button>`).join('')}let q=norm(document.getElementById('catalogSearch')?.value||'');let ps=db.products.filter(p=>(filterFactory==='Все'||p.factory===filterFactory)&&norm(p.name).includes(q));document.getElementById('catalogList').innerHTML=ps.length?ps.map(p=>`<div class="product swipe-product" data-product-id="${p.id}" ontouchstart="productTouchStart(event,'${p.id}')" ontouchend="productTouchEnd(event,'${p.id}')"><div class="product-info"><div class="pname">${esc(p.name)}</div><div class="tiny">${esc(p.factory)}</div></div><div class="product-controls"><div class="stock">${cloudStockLabel(p.id)}</div><button class="btn small secondary" onclick="event.stopPropagation();editProduct(\'${p.id}\')">✎</button></div></div>`).join(''):'<div class="empty">Ничего не найдено</div>'}
let productTouch=null;function productTouchStart(e,id){if(e.touches?.length===1)productTouch={id,x:e.touches[0].clientX,y:e.touches[0].clientY}}function productTouchEnd(e,id){if(!productTouch||productTouch.id!==id)return;let t=e.changedTouches?.[0],dx=t? t.clientX-productTouch.x:0,dy=t? t.clientY-productTouch.y:0;productTouch=null;if(dx< -75&&Math.abs(dx)>Math.abs(dy)*1.25)deleteProduct(id)}
function deleteProduct(id){let p=db.products.find(x=>x.id===id);if(!p)return;let queued=db.pending.some(o=>(o.rows||[]).some(r=>r.id===id));if(queued)return alert(`Товар «${p.name}» есть в ожидающих заявках. Сначала заверши или удали эти заявки, затем удаляй товар из каталога.`);if(!confirm(`Удалить товар «${p.name}» из каталога?\nОстаток: ${cloudStockLabel(p.id)} шт.\nЗаписи истории останутся без изменений.`))return;db.products=db.products.filter(x=>x.id!==id);Object.keys(db.aliases||{}).forEach(k=>{if(db.aliases[k]===p.name)delete db.aliases[k]});save();renderCatalog();renderOrders();renderMore()}
function adjust(id,d){if(!cloudStockMutationReady())return;const current=cloudStockNumber(id);if(current===null)return alert('Облачный остаток ещё не загружен');const delta=Number(d);if(delta<0&&current+delta<0)return alert('Нельзя списать больше, чем есть в облаке');if(cloudQueueStockDelta(id,delta))renderCatalog()}
let pendingNewProduct=null;
function editProduct(id){let p=db.products.find(x=>x.id===id);if(p&&!cloudStockMutationReady())return;let oldName=p?.name||'';let name=prompt('Название товара',oldName);if(name===null)return;name=name.trim();if(!name)return;const current=p?cloudStockNumber(id):0;if(p&&current===null)return alert('Облачный остаток ещё не загружен');let stock=prompt('Остаток (шт.)',String(current??0));if(stock===null)return;let qty=Math.max(0,parseInt(stock)||0);if(db.products.some(x=>norm(x.name)===norm(name)&&x.id!==id))return alert('Такой товар уже есть в каталоге');if(!p){pendingNewProduct={name,stock:qty};renderProductFactoryPicker(FIRST);return}let choices=[...new Set([...(db.factories||[]),...db.products.map(x=>x.factory).filter(Boolean)])];let factory=prompt('Завод/категория товара. Введи существующий завод или название нового:',p.factory||FIRST);if(factory===null)return;let f=factory.trim();if(!f)return alert('Укажи завод или категорию');if(!choices.some(x=>norm(x)===norm(f))){if(!confirm(`Создать новую категорию «${f}»?`))return;db.factories.push(f)}else f=choices.find(x=>norm(x)===norm(f));let previous=p.name;p.name=name;p.factory=f;if(previous!==name)Object.keys(db.aliases||{}).forEach(k=>{if(db.aliases[k]===previous)db.aliases[k]=name});save();if(qty!==current)cloudQueueStockSet(id,qty);renderCatalog()}
function renderProductFactoryPicker(selected){let fs=[...new Set([...(db.factories||[]),...db.products.map(p=>p.factory).filter(Boolean)])];document.getElementById('productFactoryChoices').innerHTML=fs.map(f=>`<button class=\"pill ${f===selected?'active':''}\" onclick=\"selectNewProductFactory(this.dataset.factory)\" data-factory=\"${esc(f)}\">${esc(f)}</button>`).join('');document.getElementById('productFactoryNew').value='';document.getElementById('productFactoryModal').classList.remove('hidden')}
function selectNewProductFactory(factory){if(!pendingNewProduct)return;const initialStock=Math.max(0,Number(pendingNewProduct.stock)||0),id=crypto.randomUUID();db.products.push({id,name:pendingNewProduct.name,factory});pendingNewProduct=null;save();cloudQueueStockEnsure(id,initialStock);document.getElementById('productFactoryModal').classList.add('hidden');renderCatalog()}
function createFactory(){let name=prompt('Название новой категории');if(name===null)return;name=name.trim();if(!name)return alert('Название категории не может быть пустым');let fs=[...new Set([...(db.factories||[]),...db.products.map(p=>p.factory).filter(Boolean)])];if(fs.some(f=>norm(f)===norm(name)))return alert('Такая категория уже существует');db.factories.push(name);save();renderFactoryManager();renderCatalog()}
function createFactoryForProduct(){let name=document.getElementById('productFactoryNew').value.trim();if(!name)return alert('Введи название категории');let fs=[...new Set([...(db.factories||[]),...db.products.map(p=>p.factory).filter(Boolean)])];let existing=fs.find(f=>norm(f)===norm(name));if(existing)return selectNewProductFactory(existing);db.factories.push(name);save();selectNewProductFactory(name)}
function closeProductFactoryPicker(){pendingNewProduct=null;document.getElementById('productFactoryModal').classList.add('hidden')}
function manageFactories(){renderFactoryManager();document.getElementById('factoryModal').classList.remove('hidden')}
function closeFactoryManager(){document.getElementById('factoryModal').classList.add('hidden')}
function renderFactoryManager(){let fs=[...new Set([...(db.factories||[]),...db.products.map(p=>p.factory).filter(Boolean)])];document.getElementById('factoryManagerList').innerHTML='<button class=\"btn\" onclick=\"createFactory()\">＋ Добавить категорию</button>'+ (fs.length?fs.map((f,i)=>`<div class=\"factory-manage-row\"><b>${esc(f)}</b><div><button class=\"btn small secondary\" onclick=\"renameFactory(${i})\">Переименовать</button><button class=\"btn small danger\" onclick=\"deleteFactory(${i})\">Удалить</button></div></div>`).join(''):'<div class=\"empty\">Категорий нет</div>')}
function renameFactory(i){let fs=[...new Set([...(db.factories||[]),...db.products.map(p=>p.factory).filter(Boolean)])],old=fs[i];if(!old)return;let next=prompt('Новое название категории',old);if(next===null)return;next=next.trim();if(!next)return alert('Название не может быть пустым');if(fs.some(f=>norm(f)===norm(next)&&f!==old))return alert('Такая категория уже существует');db.factories=db.factories.map(f=>f===old?next:f);db.products.forEach(p=>{if(p.factory===old)p.factory=next});if(filterFactory===old)filterFactory=next;save();renderFactoryManager();renderCatalog()}
function deleteFactory(i){let fs=[...new Set([...(db.factories||[]),...db.products.map(p=>p.factory).filter(Boolean)])],old=fs[i];if(!old)return;let used=db.products.some(p=>p.factory===old),others=fs.filter(f=>f!==old);if(used){if(!others.length)return alert('Нельзя удалить последнюю категорию, пока в ней есть товары. Сначала создай другую категорию.');let target=prompt(`В категории «${old}» есть товары. Введи точное название категории, куда их перенести:\n${others.join('\n')}`,others[0]);if(target===null)return;let found=others.find(f=>norm(f)===norm(target));if(!found)return alert('Категория не найдена. Товары не перемещены.');if(!confirm(`Перенести все товары из «${old}» в «${found}» и удалить категорию?`))return;db.products.forEach(p=>{if(p.factory===old)p.factory=found})}else if(!confirm(`Удалить пустую категорию «${old}»?`))return;db.factories=(db.factories||[]).filter(f=>f!==old);if(filterFactory===old)filterFactory='Все';save();renderFactoryManager();renderCatalog()}
let orderReviewRows=[];
function wordStem(s){return s.replace(/(иями|ями|ами|ого|ему|ому|ыми|ими|ая|яя|ое|ее|ые|ие|ой|ый|ий|ую|юю|ов|ев|ам|ям|ах|ях|а|я|ы|и|е|у|ю|о)$/,'')}
function tokenSimilarity(a,b){if(!a||!b)return 0;if(a===b)return 1;if(a.includes(b)||b.includes(a))return Math.min(a.length,b.length)/Math.max(a.length,b.length)*.92+.08;let dist=lev(a,b),edit=1-dist/Math.max(a.length,b.length);let sa=wordStem(a),sb=wordStem(b),prefix=0;while(prefix<Math.min(sa.length,sb.length)&&sa[prefix]===sb[prefix])prefix++;let stem=prefix/Math.max(sa.length,sb.length,1);let grams=x=>{let out=[];for(let i=0;i<=x.length-3;i++)out.push(x.slice(i,i+3));return out};let ga=grams(a),gb=grams(b),common=ga.filter(g=>gb.includes(g)).length,trigram=common/Math.max(ga.length,gb.length,1);return Math.max(edit,stem*.88,trigram*.9)}
function productMatchScore(raw,productName){let a=norm(raw).split(' ').filter(Boolean),b=norm(productName).split(' ').filter(Boolean);if(!a.length||!b.length)return 0;let scores=a.map(t=>Math.max(...b.map(w=>tokenSimilarity(t,w))));let useful=scores.filter(x=>x>=.48);let coverage=scores.reduce((x,y)=>x+y,0)/scores.length;let best=Math.max(...scores);let phrase=1-lev(a.join(''),b.join(''))/Math.max(a.join('').length,b.join('').length,1);return Math.max(coverage*.78+best*.22, best*.82+phrase*.18)}
function parseOrderDraft(text){return text.split(/\r?\n/).map(x=>x.trim()).filter(Boolean).map((line,index)=>{let clean=line.replace(/^\s*(?:[-*•]|\d+[.)])\s*/,'').trim();let q=clean.match(/(?:[xх×]\s*)?(\d+)\s*(?:шт\.?|кег\.?|ящ\.?|л\.?\b)?\s*$/i);let qty=q?Math.max(1,parseInt(q[1],10)):1;let name=q?clean.slice(0,q.index).replace(/[—–,:;\-]+\s*$/,'').trim():clean;name=name.replace(/\s*[xх×]\s*$/,'').trim();if(!name)return null;let n=norm(name),exact=db.products.find(p=>norm(p.name)===n),alias=db.products.find(p=>p.name===db.aliases[n]);let scored=db.products.map(p=>({p,score:productMatchScore(name,p.name)})).sort((a,b)=>b.score-a.score);let top=scored[0],second=scored[1];let selected=exact||alias||null;let threshold=Math.max(.40,(top?.score||0)-.22);let candidates=selected?[selected]:scored.filter(x=>x.score>=threshold&&x.score>=.48).slice(0,6).map(x=>x.p);return {line,name,qty,selectedId:selected?.id||'',candidates:candidates.map(p=>p.id),newFactory:FIRST,index}}).filter(Boolean)}
const voiceNumberWords={'один':1,'одна':1,'одно':1,'два':2,'две':2,'три':3,'четыре':4,'пять':5,'шесть':6,'семь':7,'восемь':8,'девять':9,'десять':10,'одиннадцать':11,'двенадцать':12,'тринадцать':13,'четырнадцать':14,'пятнадцать':15,'шестнадцать':16,'семнадцать':17,'восемнадцать':18,'девятнадцать':19,'двадцать':20,'тридцать':30,'сорок':40,'пятьдесят':50,'шестьдесят':60,'семьдесят':70,'восемьдесят':80,'девяносто':90,'сто':100};
function strictVoiceProduct(name){const key=norm(name);if(!key)return null;const aliasTarget=db.aliases?.[key];return db.products.find(p=>norm(p.name)===key||(aliasTarget&&norm(p.name)===norm(aliasTarget)))||null}
function strictVoiceChunk(chunk){let clean=norm(chunk).replace(/^(?:добавь|закажи|нужно|надо|пожалуйста|еще|ещё)\s+/,'').trim();if(!clean)return null;clean=clean.replace(/\s+(?:шт|штук|кег|ящ|ящиков|литров)$/,'').trim();let qty=1;let q=clean.match(/(?:^|\s)(\d+)$/);if(q){qty=Math.max(1,parseInt(q[1],10));clean=clean.slice(0,q.index).trim()}else{const parts=clean.split(' '),last=parts[parts.length-1];if(Object.prototype.hasOwnProperty.call(voiceNumberWords,last)){qty=Math.max(1,voiceNumberWords[last]);clean=parts.slice(0,-1).join(' ')}}const product=strictVoiceProduct(clean);return product?{id:product.id,name:product.name,qty}:null}
function voiceTranscriptItems(transcript){
 const tokens=norm(transcript).split(' ').filter(Boolean),dictionary=[];
 for(const product of db.products||[]){const canonical=norm(product.name);if(canonical)dictionary.push({key:canonical.split(' '),product})}
 for(const [alias,target] of Object.entries(db.aliases||{})){const product=(db.products||[]).find(p=>norm(p.name)===norm(target));const key=norm(alias).split(' ');if(product&&key.length)dictionary.push({key,product})}
 dictionary.sort((a,b)=>b.key.length-a.key.length);
 const units=new Set(['шт','штук','штуки','кег','кега','кегу','ящ','ящик','ящика','ящиков','литр','литра','литров']);
 function readQty(index){const token=tokens[index];let qty=null,next=index;if(token&&/^\d+$/.test(token)){qty=Math.max(1,parseInt(token,10));next=index+1}else if(token&&Object.prototype.hasOwnProperty.call(voiceNumberWords,token)){qty=voiceNumberWords[token];next=index+1;const following=tokens[next];if(qty>=20&&qty%10===0&&following&&Object.prototype.hasOwnProperty.call(voiceNumberWords,following)&&voiceNumberWords[following]<10){qty+=voiceNumberWords[following];next++}}if(qty!==null&&units.has(tokens[next]))next++;return {qty:qty===null?1:qty,next:qty===null?index:next}}
 const combined=new Map();let i=0;
 while(i<tokens.length){let found=null;for(const item of dictionary){if(item.key.every((word,j)=>tokens[i+j]===word)){found=item;break}}if(!found){i++;continue}const quantity=readQty(i+found.key.length);const row={id:found.product.id,name:found.product.name,qty:quantity.qty};const old=combined.get(String(row.id));if(old)old.qty+=row.qty;else combined.set(String(row.id),row);i=quantity.next>i+found.key.length?quantity.next:i+found.key.length;}
 return [...combined.values()]
}
function appendVoiceTranscript(transcript){const recognized=voiceTranscriptItems(transcript);const field=document.getElementById('voiceDraft');if(!field)return;const existing=field.value.split(/\r?\n/).filter(Boolean);for(const row of recognized)existing.push(`${row.name} — ${row.qty}`);field.value=existing.join('\n');const status=document.getElementById('voiceStatus');if(status)status.textContent=recognized.length?`Добавлено распознанных товаров: ${recognized.length}. Незнакомые названия пропущены.`:'В этой фразе не найдено точных названий товаров или сохранённых сокращений.'}
function selectVoiceShop(shop){activeVoiceShop=shop;renderVoiceShopButtons()}
function renderVoiceShopButtons(){document.querySelectorAll('.voice-shop-choice').forEach(b=>b.classList.toggle('active',b.dataset.voiceShop===activeVoiceShop))}
function toggleVoiceRecognition(){const Recognition=window.SpeechRecognition||window.webkitSpeechRecognition;if(voiceRecognition){voiceRecognition.stop();return}if(!Recognition){const status=document.getElementById('voiceStatus');if(status)status.textContent='Этот браузер не поддерживает голосовой ввод. Попробуй открыть приложение в Safari или Chrome с поддержкой распознавания речи.';return}const recognition=new Recognition();voiceRecognition=recognition;recognition.lang='ru-RU';recognition.continuous=true;recognition.interimResults=false;const button=document.getElementById('voiceMicButton');if(button)button.textContent='■ Остановить голосовой набор';const status=document.getElementById('voiceStatus');if(status)status.textContent='Слушаю… диктуй названия товаров и количество';recognition.onresult=event=>{for(let i=event.resultIndex;i<event.results.length;i++){const result=event.results[i];if(result.isFinal)appendVoiceTranscript(result[0].transcript)}};recognition.onerror=event=>{if(status)status.textContent='Ошибка голосового ввода: '+(event.error||'неизвестная ошибка')};recognition.onend=()=>{if(voiceRecognition===recognition)voiceRecognition=null;if(button)button.textContent='🎙️ Начать голосовой набор';if(status&&status.textContent==='Слушаю… диктуй названия товаров и количество')status.textContent='Голосовой ввод остановлен. Проверь список и добавь заявку в очередь.'};try{recognition.start()}catch(error){voiceRecognition=null;if(button)button.textContent='🎙️ Начать голосовой набор';if(status)status.textContent='Не удалось запустить микрофон: '+(error?.message||'проверь разрешение на микрофон')}}
function clearVoiceDraft(){document.getElementById('voiceDraft').value='';const status=document.getElementById('voiceStatus');if(status)status.textContent='Список очищен. Можно диктовать новую заявку.'}
function saveVoiceOrderToQueue(){const field=document.getElementById('voiceDraft');if(!field)return;const parsed=field.value.split(/\r?\n/).map(line=>strictVoiceChunk(line)).filter(Boolean);if(!parsed.length)return alert('Не распознано ни одного известного товара. Заявка не создана.');const rows=parsed.map(row=>({row_id:crypto.randomUUID(),id:row.id,name:row.name,qty:row.qty,collected:false}));db.pending.push({id:crypto.randomUUID(),shop:activeVoiceShop,date:new Date().toISOString(),rows});save();field.value='';const shopSelect=document.getElementById('shop');if(shopSelect)shopSelect.value=activeVoiceShop;renderShopButtons();renderOrders();renderCatalog();const status=document.getElementById('voiceStatus');if(status)status.textContent=`Заявка для ${activeVoiceShop} добавлена в очередь: ${rows.length} позиций.`;alert(`Заявка для ${activeVoiceShop} добавлена в очередь отгрузки.`)}

function checkOrderDraft(){try{const field=document.getElementById('orderDraft');if(!field)return alert('Не найдено поле заявки. Обнови приложение.');const text=field.value;const rows=parseOrderDraft(text);if(!rows.length)return alert('Впиши товары — каждый с новой строки');orderReviewRows=rows;renderOrderReview()}catch(err){console.error('BAVARSKI order check:',err);alert('Не удалось проверить заявку: '+(err?.message||err))}}
function renderOrderReview(){let box=document.getElementById('orderReview');box.classList.remove('hidden');box.innerHTML='<div class="row between"><b>Проверка заявки</b><span class="badge">'+orderReviewRows.length+' позиций</span></div>'+orderReviewRows.map((r,i)=>{let opts=db.products.filter(p=>r.candidates.includes(p.id));let selected=db.products.find(p=>p.id===r.selectedId);if(selected&&r.selectedId!=='__new__')return `<div class="order-review-line"><b>${esc(selected.name)} ${r.qty} шт.</b></div>`;return `<div class="itemline order-review-uncertain"><div style="min-width:0;flex:1"><b>${esc(r.name)} ${r.qty} шт.</b><div class="tiny">Похожие товары из каталога — выбери подходящий</div></div><div style="min-width:48%;flex:1"><select class="field" onchange="resolveOrderRow(${i},this.value)"><option value="">Выбрать вариант</option>${opts.map(p=>`<option value="${p.id}" ${r.selectedId===p.id?'selected':''}>${esc(p.name)} · ${cloudStockLabel(p.id)} шт.</option>`).join('')}<option value="__new__" ${r.selectedId==='__new__'?'selected':''}>＋ Добавить новый товар</option></select>${r.selectedId==='__new__'?`<select class="field" onchange="setOrderNewFactory(${i},this.value)">${[...(db.factories||[FIRST,SECOND])].map(f=>`<option value="${esc(f)}" ${r.newFactory===f?'selected':''}>${esc(f)}</option>`).join('')}</select><input class="field" placeholder="Новый завод/категория (если нужно)" onchange="setOrderNewFactory(${i},this.value)">`:''}</div></div>`}).join('')+'<button class="btn" onclick="confirmOrderQueue()">Сохранить в очередь</button><button class="btn secondary" onclick="document.getElementById(\'orderReview\').classList.add(\'hidden\')">Вернуться к списку</button>'}
function resolveOrderRow(i,value){orderReviewRows[i].selectedId=value;if(value&&value!=='__new__'){let p=db.products.find(x=>x.id===value);if(p)db.aliases[norm(orderReviewRows[i].name)]=p.name;save()}renderOrderReview()}
function setOrderNewFactory(i,value){orderReviewRows[i].newFactory=value.trim()||FIRST}
function confirmOrderQueue(){try{let unresolved=orderReviewRows.filter(r=>!r.selectedId);if(unresolved.length)return alert('Подтверди совпадение для каждой строки. Неизвестные товары можно добавить в каталог через пункт «Добавить как новый товар».');let rows=[];for(let r of orderReviewRows){let p;if(r.selectedId==='__new__'){p={id:crypto.randomUUID(),name:r.name,factory:r.newFactory||FIRST};if(!db.factories.includes(p.factory))db.factories.push(p.factory);db.products.push(p);cloudQueueStockEnsure(p.id,0);db.aliases[norm(r.name)]=r.name}else p=db.products.find(x=>x.id===r.selectedId);if(!p){alert('Не удалось подтвердить товар: '+r.name);return}rows.push({row_id:crypto.randomUUID(),id:p.id,name:p.name,qty:r.qty,collected:false})}db.pending.push({id:crypto.randomUUID(),shop:document.getElementById('shop').value,date:new Date().toISOString(),rows});db.current=[];orderReviewRows=[];document.getElementById('orderDraft').value='';document.getElementById('orderReview').classList.add('hidden');save();renderOrders();renderCatalog();alert('Заявка проверена и сохранена в очереди')}catch(err){console.error('BAVARSKI queue save:',err);alert('Не удалось сохранить заявку: '+(err?.message||err))}}
function selectShop(shop){document.getElementById('shop').value=shop;renderShopButtons();renderOrders()}
function renderShopButtons(){let current=document.getElementById('shop')?.value||'БАВ 1';document.querySelectorAll('.shop-choice').forEach(b=>b.classList.toggle('active',b.dataset.shop===current))}
function clearOrderDraft(){document.getElementById('orderDraft').value='';document.getElementById('orderReview').classList.add('hidden');orderReviewRows=[]}
function renderOrders(){
 let host=document.getElementById('pendingOrders');
 let activeShop=document.getElementById('shop')?.value||'';
 let visible=db.pending.map((o,i)=>({o,i})).filter(x=>!activeShop||x.o.shop===activeShop);
 let shopRows=visible.flatMap(x=>(x.o.rows||[]).filter(r=>!r.collected));
 let shopFirst=shopRows.filter(r=>db.products.find(p=>p.id===r.id)?.factory===FIRST).reduce((n,r)=>n+(Number(r.qty)||0),0);
 let shopSecond=shopRows.filter(r=>db.products.find(p=>p.id===r.id)?.factory===SECOND).reduce((n,r)=>n+(Number(r.qty)||0),0);
 let shopExtra=[...new Set(shopRows.map(r=>db.products.find(p=>p.id===r.id)?.factory).filter(f=>f&&!([FIRST,SECOND].includes(f))))].map(f=>`${esc(f)}: ${shopRows.filter(r=>db.products.find(p=>p.id===r.id)?.factory===f).reduce((n,r)=>n+(Number(r.qty)||0),0)} штук`);
 let shopParts=[];if(shopFirst>0)shopParts.push(`ПЕРВОРЕЧЕНСКИЙ ЗАВОД: ${shopFirst} штук`);if(shopSecond>0)shopParts.push(`ОСЕТИНСКИЙ ЗАВОД: ${shopSecond} штук`);shopParts.push(...shopExtra);let shopSummary=visible.length&&shopParts.length?`<div class="pending-totals shop-pending-totals"><b>К сборке для ${esc(activeShop)}</b><br>${shopParts.join('<br>')}</div>`:'';
 host.innerHTML=visible.length?shopSummary+visible.map(({o,i})=>{
  let rows=(o.rows||[]).map((r,j)=>{if(typeof r.collected!=='boolean')r.collected=false;return `<label class="itemline pending-product-line" style="align-items:center"><input type="checkbox" ${r.collected?'checked':''} onchange="toggleCollected(${i},${j},this.checked)"><span class="pending-product-name"><b>${esc(r.name)}</b><b>${r.qty} шт.</b></span><span class="tiny">Остаток: ${cloudStockLabel(r.id)}</span></label>`}).join('');
  let remaining=(o.rows||[]).filter(r=>!r.collected);let firstTotal=remaining.filter(r=>db.products.find(p=>p.id===r.id)?.factory===FIRST).reduce((n,r)=>n+(Number(r.qty)||0),0);let secondTotal=remaining.filter(r=>db.products.find(p=>p.id===r.id)?.factory===SECOND).reduce((n,r)=>n+(Number(r.qty)||0),0);
  let otherTotals=[...new Set(remaining.map(r=>db.products.find(p=>p.id===r.id)?.factory).filter(f=>f&&!([FIRST,SECOND].includes(f))))].map(f=>`${esc(f)}: ${remaining.filter(r=>db.products.find(p=>p.id===r.id)?.factory===f).reduce((n,r)=>n+(Number(r.qty)||0),0)} штук`).filter(x=>!/: 0 штук$/.test(x));
  let done=(o.rows||[]).filter(r=>r.collected).length;let totalParts=[];if(firstTotal>0)totalParts.push(`ПЕРВОРЕЧЕНСКИЙ ЗАВОД: ${firstTotal} штук`);if(secondTotal>0)totalParts.push(`ОСЕТИНСКИЙ ЗАВОД: ${secondTotal} штук`);totalParts.push(...otherTotals);let totalsHtml=totalParts.length?`<div class="pending-totals">${totalParts.join('<br>')}</div>`:'';let dt=new Date(o.date);
  return `<details class="pending-card" ${openedPendingId===o.id?'open':''} ontoggle="setPendingOpen('${o.id}',this.open)"><summary><span class="pending-summary-main"><span class="pending-summary-title">${esc(o.shop)}: ${dt.toLocaleDateString('ru-RU')}, ${dt.toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'})}</span><span class="pending-summary-meta">1 заявка, ожидает отгрузки</span></span><span class="pending-summary-arrow">⌄</span></summary><div class="tiny" style="margin-top:10px">Собрано ${done} из ${(o.rows||[]).length} позиций</div>${rows}${totalsHtml}<button class="btn" onclick="dispatch(${i})">Отгрузить и списать</button><button class="btn small secondary" onclick="loadPending(${i})">Открыть для исправления</button><button class="btn small danger" onclick="deletePending(${i})">Удалить заявку</button></details>`
 }).join(''):`<div class="empty">Для магазина «${esc(activeShop)}» ожидающих заявок нет</div>`;
 let sh=document.getElementById('shipmentHistory');
 db.shipments.sort((a,b)=>(Date.parse(b.date)||0)-(Date.parse(a.date)||0)||String(b.id||'').localeCompare(String(a.id||'')));
 sh.innerHTML=db.shipments.length?db.shipments.map((e,i)=>{const historyId=String(e.id||`${e.shop||''}-${e.date||i}`);return `<details class=\"history-entry shipment-card\" data-shipment-id=\"${esc(historyId)}\" ${openedShipmentIds.has(historyId)?'open':''}><summary class=\"shipment-summary\" onclick=\"event.preventDefault()\"><b>${esc(e.shop)}</b><span class=\"tiny\">${new Date(e.date).toLocaleString('ru-RU')}</span><button type=\"button\" class=\"history-toggle\" aria-label=\"Раскрыть историю отгрузки\" onclick=\"toggleShipmentHistory(event,this)\">⌄</button></summary><div class=\"history-lines\">${esc((e.rows||[]).map(r=>`${r.name} — ${r.qty} шт.`).join('\n'))}</div><div class=\"history-actions\"><button class=\"btn small\" onclick=\"shareShipment(${i})\">Поделиться</button><button class=\"btn small danger\" onclick=\"deleteHistoryEntry('shipments',${i})\">Удалить</button></div></details>`}).join(''):'<div class=\"empty\">Отгрузок пока нет</div>';
}
function shareShipment(index){let e=db.shipments[index];if(!e)return;let d=new Date(e.date);let date=d.toLocaleDateString('ru-RU'),time=d.toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'});let lines=[`${e.shop}, ${date}, ${time}`,...(e.rows||[]).map(r=>`${r.name} - ${r.qty}`)];shareText(lines.join('\n'),`Заявка ${e.shop}`)}
function setPendingOpen(id,isOpen){if(isOpen)openedPendingId=id;else if(openedPendingId===id)openedPendingId=null}
function toggleShipmentHistory(event,button){event.preventDefault();event.stopPropagation();const detail=button?.closest('details.shipment-card');if(!detail)return;const id=detail.dataset.shipmentId;if(detail.open){detail.open=false;openedShipmentIds.delete(id)}else{detail.open=true;openedShipmentIds.add(id)}}
function toggleCollected(i,j,v){let order=db.pending[i],r=order?.rows[j];if(!r)return;v=!!v;if(v){const available=cloudStockNumber(r.id);if(available===null){alert('Остаток ещё не загружен из облака.');v=false}else if(available<r.qty){if(available>0){if(!confirm(`Недостаточно товара «${r.name}» на остатке.\nВ заявке: ${r.qty} шт.\nДоступно: ${available} шт.\n\nСписать доступное количество — ${available} шт. и изменить количество в заявке?`))v=false;else r.qty=available}else{alert(`Товара «${r.name}» нет на остатке. Отметить его для отгрузки нельзя.`);v=false}}}r.collected=v;openedPendingId=order?.id||openedPendingId;save();renderOrders();}
function dispatch(i){if(!cloudStockMutationReady())return;let o=db.pending[i];if(!o)return;let selected=o.rows.filter(r=>r.collected);if(!selected.length)return alert('Сначала отметь галочками собранные товары');const availableById=new Map(),totals=new Map();for(const r of selected){const id=String(r.id),available=cloudStockNumber(id);if(available===null){availableById.set(id,null);continue}availableById.set(id,available);totals.set(id,(totals.get(id)||0)+(Number(r.qty)||0))}const shortages=[...totals].filter(([id,total])=>availableById.get(id)===null||availableById.get(id)<total);if(shortages.length){const message=shortages.map(([id,total])=>{const row=selected.find(r=>String(r.id)===id);const available=availableById.get(id);return `${row?.name||id}: в заявке ${total} шт., доступно ${available===null?'не загружено':available} шт.`}).join('\n');if(!confirm('После сборки остатки изменились.\n'+message+'\n\nУменьшить количество в заявке до доступного и продолжить отгрузку?'))return;const remaining=new Map(availableById);for(const r of selected){const id=String(r.id),budget=remaining.get(id);if(budget===null||budget===undefined||budget<=0){r.collected=false;continue}const qty=Math.min(Number(r.qty)||0,budget);r.qty=qty;remaining.set(id,budget-qty);if(qty<=0)r.collected=false}save();selected=o.rows.filter(r=>r.collected);if(!selected.length){renderOrders();return alert('На складе нет доступного количества для отгрузки.')}}const confirmedTotals=new Map();for(const r of selected){const id=String(r.id);confirmedTotals.set(id,(confirmedTotals.get(id)||0)+(Number(r.qty)||0))}for(const [id,total] of confirmedTotals){const available=cloudStockNumber(id);if(available===null||available<total)throw new Error(`Недостаточный или не загруженный остаток: ${selected.find(r=>String(r.id)===id)?.name||id}`)}for(const [id,total] of confirmedTotals)cloudQueueStockDelta(id,-total);let shipped={...o,id:crypto.randomUUID(),date:new Date().toISOString(),rows:structuredClone(selected)};db.shipments.unshift(shipped);o.rows=o.rows.filter(r=>!r.collected);if(!o.rows.length)db.pending.splice(i,1);else{o.date=new Date().toISOString()}save();renderOrders();renderCatalog();alert(o.rows.length?'Отгрузка отправлена в облако. Остатки обновятся после подтверждения Supabase; остальные позиции остались в очереди.':'Отгрузка отправлена в облако. Остатки обновятся после подтверждения Supabase; заявка закрыта.')}
function loadPending(i){let o=db.pending[i];if(!o)return;document.getElementById('shop').value=o.shop;renderShopButtons();document.getElementById('orderDraft').value=o.rows.map(r=>`${r.name} — ${r.qty}`).join('\n');db.pending.splice(i,1);save();renderOrders();checkOrderDraft()}
function deletePending(i){if(confirm('Удалить заявку из очереди?')){db.pending.splice(i,1);save();renderOrders()}}
function copyOrder(){let text=`ЗАЯВКА — ${document.getElementById('shop').value}\n\n`+document.getElementById('orderDraft').value;if(!document.getElementById('orderDraft').value.trim())return alert('Заявка пустая');if(navigator.clipboard?.writeText)navigator.clipboard.writeText(text).then(()=>alert('Текст скопирован')).catch(()=>prompt('Скопируй текст',text));else prompt('Скопируй текст',text)}
function backup(){let blob=new Blob([JSON.stringify(db,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`BAVARSKI-backup-${new Date().toISOString().slice(0,10)}.json`;a.click();URL.revokeObjectURL(a.href)}function restore(e){let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{try{let x=JSON.parse(r.result);if(!Array.isArray(x.products))throw Error();if(!confirm('Заменить текущие данные содержимым копии?'))return;db={...defaults,...x};save();location.reload()}catch(err){alert('Файл не похож на резервную копию BAVARSKI')}};r.readAsText(f)}
function renderMore(){return}
function resetData(){if(confirm('Точно удалить все товары, остатки, заявки и историю? Сначала сделай резервную копию.')){['bavarskiDB','bavarskiDBSavedAt','bavarskiStockQueue','bavarskiMetaOpQueue'].forEach(k=>localStorage.removeItem(k));try{const req=indexedDB.deleteDatabase('BAVARSKI_DB');req.onerror=()=>console.warn('Не удалось очистить локальную базу',req.error);req.onsuccess=()=>location.reload();req.onblocked=()=>{alert('Закрой другие вкладки BAVARSKI и повтори сброс.');location.reload()}}catch(e){location.reload()}}}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
setCloudStatus('Ожидаем загрузку данных из облака…');hydrationPromise=hydrate();hydrationPromise.then(()=>restoreCloud());window.addEventListener('online',()=>{if(!cloudReady)restoreCloud();else{cloudDrainMetaOps();cloudDrainStockQueue();pollCloud()}});document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'){if(!cloudReady)restoreCloud();else{cloudDrainMetaOps();cloudDrainStockQueue();pollCloud()}}});if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
