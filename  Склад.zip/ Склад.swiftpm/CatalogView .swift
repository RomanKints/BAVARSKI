
import SwiftUI

// MARK: - Модель товара

struct CatalogProduct: Identifiable, Codable {
    let id: UUID
    var name: String
    var stock: Int
    var factory: String
    
    static let firstFactory = "ПЕРВОРЕЧЕНСКИЙ ЗАВОД"
    static let secondFactory = "ОСЕТИНСКИЙ ЗАВОД"
    
    init(
        name: String,
        stock: Int,
        factory: String = CatalogProduct.firstFactory
    ) {
        self.id = UUID()
        self.name = name
        self.stock = stock
        self.factory = factory
    }
    
    enum CodingKeys: String, CodingKey {
        case id
        case name
        case stock
        case factory
    }
    
    // Поддержка старых сохранённых товаров
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        id = try container.decode(UUID.self, forKey: .id)
        name = try container.decode(String.self, forKey: .name)
        stock = try container.decode(Int.self, forKey: .stock)
        
        factory = try container.decodeIfPresent(
            String.self,
            forKey: .factory
        ) ?? CatalogProduct.firstFactory
    }
}

// MARK: - Редактор товара

struct ProductEditorView: View {
    
    @Environment(\.dismiss) private var dismiss
    
    let product: CatalogProduct?
    let onSave: (String, Int, String) -> Void
    
    @State private var name: String
    @State private var stock: Int
    @State private var factory: String
    
    init(
        product: CatalogProduct?,
        onSave: @escaping (String, Int, String) -> Void
    ) {
        self.product = product
        self.onSave = onSave
        
        _name = State(initialValue: product?.name ?? "")
        _stock = State(initialValue: product?.stock ?? 0)
        
        _factory = State(
            initialValue: product?.factory ?? CatalogProduct.secondFactory
        )
    }
    
    var body: some View {
        
        NavigationStack {
            
            Form {
                
                Section("Название товара") {
                    
                    TextField("Название товара", text: $name)
                }
                
                Section("Завод") {
                    
                    Picker("Завод", selection: $factory) {
                        
                        Text(CatalogProduct.firstFactory)
                            .tag(CatalogProduct.firstFactory)
                        
                        Text(CatalogProduct.secondFactory)
                            .tag(CatalogProduct.secondFactory)
                    }
                }
                
                Section("Остаток на складе") {
                    
                    Stepper(
                        "Количество: \(stock)",
                        value: $stock,
                        in: 0...99999
                    )
                }
            }
            .navigationTitle(
                product == nil ? "Новый товар" : "Изменить товар"
            )
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                
                ToolbarItem(placement: .cancellationAction) {
                    
                    Button("Отмена") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .confirmationAction) {
                    
                    Button("Сохранить") {
                        
                        let trimmedName = name.trimmingCharacters(
                            in: .whitespacesAndNewlines
                        )
                        
                        guard !trimmedName.isEmpty else {
                            return
                        }
                        
                        onSave(trimmedName, stock, factory)
                        dismiss()
                    }
                    .disabled(
                        name.trimmingCharacters(
                            in: .whitespacesAndNewlines
                        ).isEmpty
                    )
                }
            }
        }
    }
}

// MARK: - Каталог

struct CatalogView: View {
    
    private static let storageKey = "savedBeerCatalog"
    
    private static let factories = [
        CatalogProduct.firstFactory,
        CatalogProduct.secondFactory
    ]
    
    @State private var products: [CatalogProduct] =
    CatalogView.loadProducts()
    
    @State private var editor: ProductEditor?
    @State private var productToDelete: CatalogProduct?
    @State private var showingDeleteConfirmation = false
    @State private var showingDuplicateAlert = false
    
    struct ProductEditor: Identifiable {
        let id = UUID()
        let product: CatalogProduct?
    }
    
    // MARK: - Первоначальные товары
    
    private static func initialProducts() -> [CatalogProduct] {
        
        return [
            CatalogProduct(name: "Бойлерное св.", stock: 4),
            CatalogProduct(name: "Бойлерное НФ.", stock: 5),
            CatalogProduct(name: "Белое", stock: 0),
            CatalogProduct(name: "Чех НФ.", stock: 2),
            CatalogProduct(name: "Чех св.", stock: 0),
            CatalogProduct(name: "Первореченское св.", stock: 3),
            CatalogProduct(name: "Первореченское НФ.", stock: 5),
            CatalogProduct(name: "Пшеничное", stock: 6),
            CatalogProduct(name: "Домашнее", stock: 0),
            CatalogProduct(name: "Краснодарское св.", stock: 5),
            CatalogProduct(name: "Краснодарское НФ.", stock: 4),
            CatalogProduct(name: "Танковое св.", stock: 2),
            CatalogProduct(name: "Танковое НФ.", stock: 3),
            CatalogProduct(name: "Советское св.", stock: 0),
            CatalogProduct(name: "Советское НФ.", stock: 1),
            CatalogProduct(name: "Лагер св.", stock: 0),
            CatalogProduct(name: "Лагер НФ.", stock: 4),
            CatalogProduct(name: "Безалкогольное", stock: 0),
            CatalogProduct(name: "Сухумское св.", stock: 0),
            CatalogProduct(name: "Сухумское НФ.", stock: 0),
            CatalogProduct(name: "Фирменное св.", stock: 1),
            CatalogProduct(name: "Эль", stock: 0),
            CatalogProduct(name: "Венское", stock: 4)
        ]
    }
    
    // MARK: - Новые товары Осетинского завода
    
    private static func ossetianProducts() -> [CatalogProduct] {
        
        return [
            CatalogProduct(
                name: "Бавария св",
                stock: 0,
                factory: CatalogProduct.secondFactory
            ),
            CatalogProduct(
                name: "Бавария нф",
                stock: 3,
                factory: CatalogProduct.secondFactory
            ),
            CatalogProduct(
                name: "Бавария темная",
                stock: 8,
                factory: CatalogProduct.secondFactory
            ),
            CatalogProduct(
                name: "Бельгийское",
                stock: 6,
                factory: CatalogProduct.secondFactory
            ),
            CatalogProduct(
                name: "Осетия св",
                stock: 0,
                factory: CatalogProduct.secondFactory
            ),
            CatalogProduct(
                name: "Осетия нф",
                stock: 4,
                factory: CatalogProduct.secondFactory
            ),
            CatalogProduct(
                name: "Немецкое",
                stock: 1,
                factory: CatalogProduct.secondFactory
            ),
            CatalogProduct(
                name: "Жигулёвское",
                stock: 0,
                factory: CatalogProduct.secondFactory
            )
        ]
    }
    
    // MARK: - Загрузка и обновление каталога
    
    static func loadProducts() -> [CatalogProduct] {
        
        var loadedProducts: [CatalogProduct]
        
        if let data = UserDefaults.standard.data(forKey: storageKey),
           let saved = try? JSONDecoder().decode(
            [CatalogProduct].self,
            from: data
           ) {
            
            loadedProducts = saved
            
        } else {
            
            loadedProducts = initialProducts()
        }
        
        // Добавляем новые товары только один раз
        for newProduct in ossetianProducts() {
            
            let alreadyExists = loadedProducts.contains {
                $0.name.lowercased() == newProduct.name.lowercased()
            }
            
            if !alreadyExists {
                loadedProducts.append(newProduct)
            }
        }
        
        loadedProducts.sort {
            $0.name.localizedCaseInsensitiveCompare($1.name)
            == .orderedAscending
        }
        
        // Сохраняем миграцию и новые товары
        if let data = try? JSONEncoder().encode(loadedProducts) {
            
            UserDefaults.standard.set(
                data,
                forKey: storageKey
            )
        }
        
        return loadedProducts
    }
    
    // MARK: - Сохранение
    
    private func saveProducts() {
        
        if let data = try? JSONEncoder().encode(products) {
            
            UserDefaults.standard.set(
                data,
                forKey: Self.storageKey
            )
        }
    }
    
    private func reloadProducts() {
        products = Self.loadProducts()
    }
    
    // MARK: - Изменение остатка
    
    private func changeStock(at index: Int, by amount: Int) {
        
        guard products.indices.contains(index) else {
            return
        }
        
        let newStock = products[index].stock + amount
        
        guard newStock >= 0 else {
            return
        }
        
        products[index].stock = newStock
        saveProducts()
    }
    
    // MARK: - Добавление и редактирование
    
    private func saveProduct(
        name: String,
        stock: Int,
        factory: String,
        editingProduct: CatalogProduct?
    ) {
        
        let normalizedName = name.lowercased()
        
        let duplicate = products.contains { item in
            
            item.name.lowercased() == normalizedName &&
            item.id != editingProduct?.id
        }
        
        guard !duplicate else {
            showingDuplicateAlert = true
            return
        }
        
        if let editingProduct = editingProduct,
           let index = products.firstIndex(where: {
               $0.id == editingProduct.id
           }) {
            
            products[index].name = name
            products[index].stock = stock
            products[index].factory = factory
            
        } else {
            
            products.append(
                CatalogProduct(
                    name: name,
                    stock: stock,
                    factory: factory
                )
            )
        }
        
        products.sort {
            $0.name.localizedCaseInsensitiveCompare($1.name)
            == .orderedAscending
        }
        
        saveProducts()
    }
    
    // MARK: - Удаление
    
    private func deleteProduct() {
        
        guard let product = productToDelete else {
            return
        }
        
        products.removeAll {
            $0.id == product.id
        }
        
        saveProducts()
        productToDelete = nil
    }
    
    // MARK: - Строка товара
    
    private func productRow(_ product: CatalogProduct) -> some View {
        
        HStack {
            
            Text(product.name)
                .font(.body)
                .contentShape(Rectangle())
                .onTapGesture {
                    editor = ProductEditor(product: product)
                }
            
            Spacer()
            
            Button {
                
                if let index = products.firstIndex(where: {
                    $0.id == product.id
                }) {
                    changeStock(at: index, by: -1)
                }
                
            } label: {
                
                Image(systemName: "minus.circle.fill")
                    .font(.title2)
                    .foregroundColor(.red)
            }
            .buttonStyle(.plain)
            
            Text("\(product.stock)")
                .font(.title3)
                .bold()
                .frame(minWidth: 35)
            
            Button {
                
                if let index = products.firstIndex(where: {
                    $0.id == product.id
                }) {
                    changeStock(at: index, by: 1)
                }
                
            } label: {
                
                Image(systemName: "plus.circle.fill")
                    .font(.title2)
                    .foregroundColor(.green)
            }
            .buttonStyle(.plain)
        }
        .padding(.vertical, 5)
        .swipeActions(
            edge: .trailing,
            allowsFullSwipe: false
        ) {
            
            Button(role: .destructive) {
                
                productToDelete = product
                showingDeleteConfirmation = true
                
            } label: {
                
                Label("Удалить", systemImage: "trash")
            }
            
            Button {
                
                editor = ProductEditor(product: product)
                
            } label: {
                
                Label("Изменить", systemImage: "pencil")
            }
            .tint(.blue)
        }
    }
    
    // MARK: - Интерфейс
    
    var body: some View {
        
        List {
            
            ForEach(Self.factories, id: \.self) { factory in
                
                Section {
                    
                    ForEach(
                        products.filter { $0.factory == factory }
                    ) { product in
                        
                        productRow(product)
                    }
                    
                } header: {
                    
                    Text(factory)
                        .font(.headline)
                        .foregroundColor(.primary)
                }
            }
        }
        .navigationTitle("Каталог товаров")
        .toolbar {
            
            ToolbarItem(placement: .topBarTrailing) {
                
                Button {
                    
                    editor = ProductEditor(product: nil)
                    
                } label: {
                    
                    Image(systemName: "plus")
                }
            }
        }
        .sheet(item: $editor) { item in
            
            ProductEditorView(
                product: item.product
            ) { name, stock, factory in
                
                saveProduct(
                    name: name,
                    stock: stock,
                    factory: factory,
                    editingProduct: item.product
                )
            }
        }
        .confirmationDialog(
            "Удалить этот товар?",
            isPresented: $showingDeleteConfirmation,
            titleVisibility: .visible
        ) {
            
            Button("Удалить", role: .destructive) {
                deleteProduct()
            }
            
            Button("Отмена", role: .cancel) {
                productToDelete = nil
            }
        }
        .alert(
            "Такой товар уже есть",
            isPresented: $showingDuplicateAlert
        ) {
            
            Button("Понятно", role: .cancel) { }
            
        } message: {
            
            Text("Используй другое название.")
        }
        .onAppear {
            reloadProducts()
        }
    }
}
