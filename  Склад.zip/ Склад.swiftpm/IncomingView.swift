
import SwiftUI
import UIKit

// MARK: - Модель истории прихода

struct IncomingHistoryEntry: Identifiable, Codable {
    var id = UUID()
    var date = Date()
    var added: [String]
    var skipped: [String]
}

// MARK: - Модель строки прихода

struct IncomingRow: Identifiable {
    let id = UUID()
    let originalLine: String
    let productName: String
    let quantity: Int
    var candidates: [String]
    var selectedName: String
}

// MARK: - Подробности прихода

struct IncomingHistoryDetailView: View {
    
    let entry: IncomingHistoryEntry
    
    var body: some View {
        NavigationStack {
            List {
                Section("Информация о приходе") {
                    Text(
                        entry.date.formatted(
                            date: .complete,
                            time: .shortened
                        )
                    )
                }
                
                Section("Оприходовано") {
                    if entry.added.isEmpty {
                        Text("Нет оприходованных товаров")
                            .foregroundColor(.secondary)
                    } else {
                        ForEach(entry.added, id: \.self) { item in
                            Text(item)
                                .foregroundColor(.green)
                        }
                    }
                }
                
                Section("Пропущено") {
                    if entry.skipped.isEmpty {
                        Text("Нет пропущенных товаров")
                            .foregroundColor(.secondary)
                    } else {
                        ForEach(entry.skipped, id: \.self) { item in
                            Text(item)
                                .foregroundColor(.red)
                        }
                    }
                }
            }
            .navigationTitle("Приход товара")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

// MARK: - Приход товара

struct IncomingView: View {
    
    private let storageKey = "savedBeerCatalog"
    private let historyKey = "savedIncomingHistory"
    private let learnedAliasesKey = "learnedBeerAliases"
    
    @State private var importedText = ""
    @State private var status = "Вставь список поступления"
    @State private var rows: [IncomingRow] = []
    @State private var prepared = false
    
    @State private var history: [IncomingHistoryEntry] = []
    @State private var selectedHistoryEntry: IncomingHistoryEntry?
    
    @State private var learnedAliases: [String: String] = [:]
    
    private let aliases: [String: String] = [
        "сухум нф": "Сухумское НФ.",
        "сухум св": "Сухумское св.",
        "лагерь св": "Лагер св.",
        "лагер св": "Лагер св.",
        "лагерь нф": "Лагер НФ.",
        "лагер нф": "Лагер НФ.",
        "фирменное св": "Фирменное св.",
        "фирменное нф": "Фирменное НФ.",
        "танк нф": "Танковое НФ.",
        "танк св": "Танковое св.",
        "чех св": "Чех св.",
        "чех нф": "Чех НФ.",
        "перворечка св": "Первореченское св.",
        "перворечка нф": "Первореченское НФ.",
        "первореченское св": "Первореченское св.",
        "первореченское нф": "Первореченское НФ.",
        "краснодар св": "Краснодарское св.",
        "краснодар нф": "Краснодарское НФ."
    ]
    
    // MARK: - Нормализация
    
    private func normalize(_ text: String) -> String {
        
        let folded = text.folding(
            options: [.caseInsensitive, .diacriticInsensitive],
            locale: Locale(identifier: "ru_RU")
        )
        
        let allowed = folded.map {
            $0.isLetter || $0.isNumber ? $0 : " "
        }
        
        return String(allowed)
            .split(whereSeparator: { $0.isWhitespace })
            .joined(separator: " ")
    }
    
    // MARK: - Поиск совпадающих букв
    
    private func longestCommonSubstring(
        _ first: String,
        _ second: String
    ) -> Int {
        
        let a = Array(normalize(first))
        let b = Array(normalize(second))
        
        if a.isEmpty || b.isEmpty {
            return 0
        }
        
        var previous = Array(
            repeating: 0,
            count: b.count + 1
        )
        
        var best = 0
        
        for i in 1...a.count {
            
            var current = Array(
                repeating: 0,
                count: b.count + 1
            )
            
            for j in 1...b.count {
                
                if a[i - 1] == b[j - 1] {
                    current[j] = previous[j - 1] + 1
                    best = max(best, current[j])
                }
            }
            
            previous = current
        }
        
        return best
    }
    
    // MARK: - Загрузка запомненных названий
    
    private func loadLearnedAliases() {
        
        guard let saved = UserDefaults.standard.dictionary(
            forKey: learnedAliasesKey
        ) as? [String: String] else {
            learnedAliases = [:]
            return
        }
        
        learnedAliases = saved
    }
    
    // MARK: - Сохранение запомненных названий
    
    private func saveLearnedAliases() {
        
        UserDefaults.standard.set(
            learnedAliases,
            forKey: learnedAliasesKey
        )
    }
    
    // MARK: - Поиск товара
    
    private func findCandidates(
        for name: String,
        products: [CatalogProduct]
    ) -> (candidates: [String], autoSelect: Bool) {
        
        let search = normalize(name)
        
        // Запомненные названия
        
        if let learnedTarget = learnedAliases[search] {
            
            let matches = products.filter {
                normalize($0.name) == normalize(learnedTarget)
            }
            
            if let match = matches.first {
                return ([match.name], true)
            }
        }
        
        // Встроенные сокращения
        
        if let aliasTarget = aliases.first(where: {
            normalize($0.key) == search
        })?.value {
            
            let matches = products.filter {
                normalize($0.name) == normalize(aliasTarget)
            }
            
            if let match = matches.first {
                return ([match.name], true)
            }
        }
        
        // Просто «Сухумское»
        
        if search == "сухумское" || search == "сухум" {
            
            let matches = products.filter {
                normalize($0.name).hasPrefix("сухумское")
            }
            
            return (matches.map { $0.name }, false)
        }
        
        // Точное совпадение
        
        if let exact = products.first(where: {
            normalize($0.name) == search
        }) {
            return ([exact.name], true)
        }
        
        // Похожие названия
        
        var scoredProducts: [(name: String, score: Int)] = []
        
        for product in products {
            
            let score = longestCommonSubstring(
                search,
                product.name
            )
            
            if score >= 3 {
                scoredProducts.append(
                    (name: product.name, score: score)
                )
            }
        }
        
        scoredProducts.sort {
            $0.score > $1.score
        }
        
        let names = scoredProducts.map {
            $0.name
        }
        
        return (names, false)
    }
    
    // MARK: - Загрузка каталога
    
    private func loadProducts() -> [CatalogProduct]? {
        
        guard let data = UserDefaults.standard.data(
            forKey: storageKey
        ) else {
            return nil
        }
        
        guard let products = try? JSONDecoder().decode(
            [CatalogProduct].self,
            from: data
        ) else {
            return nil
        }
        
        return products
    }
    
    // MARK: - Загрузка истории
    
    private func loadHistory() {
        
        guard let data = UserDefaults.standard.data(
            forKey: historyKey
        ) else {
            history = []
            return
        }
        
        guard let savedHistory = try? JSONDecoder().decode(
            [IncomingHistoryEntry].self,
            from: data
        ) else {
            history = []
            return
        }
        
        history = savedHistory
    }
    
    // MARK: - Удаление истории
    
    private func deleteHistoryEntry(
        _ entry: IncomingHistoryEntry
    ) {
        
        history.removeAll {
            $0.id == entry.id
        }
        
        guard let data = try? JSONEncoder().encode(history) else {
            status = "Ошибка сохранения истории"
            return
        }
        
        UserDefaults.standard.set(
            data,
            forKey: historyKey
        )
    }
    
    // MARK: - Распознавание списка
    
    private func prepareImport() {
        
        guard let products = loadProducts() else {
            status = "Не удалось загрузить каталог"
            return
        }
        
        var newRows: [IncomingRow] = []
        
        let lines = importedText.components(
            separatedBy: .newlines
        )
        
        for line in lines {
            
            var content = line.trimmingCharacters(
                in: .whitespacesAndNewlines
            )
            
            if content.isEmpty {
                continue
            }
            
            // Убираем отметки и маркеры списка
            
            let markers: [String] = [
                "- [x]",
                "- [X]",
                "- [ ]",
                "☑",
                "☐",
                "✓",
                "✔",
                "✗",
                "✘",
                "•",
                "-",
                "–"
            ]
            
            for marker in markers {
                
                if content.hasPrefix(marker) {
                    
                    content = String(
                        content.dropFirst(marker.count)
                    )
                    
                    content = content.trimmingCharacters(
                        in: .whitespacesAndNewlines
                    )
                    
                    break
                }
            }
            
            // Разбиваем строку на слова
            
            var parts = content.split(
                whereSeparator: { $0.isWhitespace }
            )
            
            // Убираем нумерацию: 1. или 2)
            
            if let first = parts.first {
                
                let number = String(first)
                
                if number.range(
                    of: #"^\d+[\.\)]$"#,
                    options: .regularExpression
                ) != nil {
                    parts = Array(parts.dropFirst())
                }
            }
            
            // Последнее слово — количество
            
            guard let last = parts.last else {
                continue
            }
            
            guard let quantity = Int(last), quantity > 0 else {
                continue
            }
            
            let nameParts = parts.dropLast()
            let name = nameParts.joined(separator: " ")
            
            if name.isEmpty {
                continue
            }
            
            let result = findCandidates(
                for: name,
                products: products
            )
            
            var selected = ""
            
            if result.autoSelect &&
                result.candidates.count == 1 {
                selected = result.candidates[0]
            }
            
            let newRow = IncomingRow(
                originalLine: line,
                productName: name,
                quantity: quantity,
                candidates: result.candidates,
                selectedName: selected
            )
            
            newRows.append(newRow)
        }
        
        rows = newRows
        prepared = true
        
        if rows.isEmpty {
            status = "Товары не найдены. Проверь список и количество"
        } else {
            status = "Найдено товаров: \(rows.count)"
        }
    }
    
    // MARK: - Запоминание новых названий
    
    private func learnAliases() {
        
        let builtInNames = aliases.keys.map {
            normalize($0)
        }
        
        for row in rows {
            
            let search = normalize(row.productName)
            let selected = row.selectedName
            
            if search.isEmpty || selected.isEmpty {
                continue
            }
            
            if search == normalize(selected) {
                continue
            }
            
            if builtInNames.contains(search) {
                continue
            }
            
            learnedAliases[search] = selected
        }
        
        saveLearnedAliases()
    }
    
    // MARK: - Оприходование товара
    
    private func applyIncoming() {
        
        guard var products = loadProducts() else {
            status = "Ошибка загрузки каталога"
            return
        }
        
        if rows.isEmpty {
            status = "Список пуст"
            return
        }
        
        // Проверяем подтверждение всех позиций
        
        for row in rows {
            
            if row.selectedName.isEmpty ||
                row.candidates.isEmpty {
                status = "Сначала выбери все товары"
                return
            }
        }
        
        let groupedRows = Dictionary(
            grouping: rows,
            by: { $0.selectedName }
        )
        
        var added: [String] = []
        var skipped: [String] = []
        
        for (name, productRows) in groupedRows {
            
            guard let index = products.firstIndex(where: {
                $0.name == name
            }) else {
                
                skipped.append(
                    "\(name) — товар не найден в каталоге"
                )
                
                continue
            }
            
            var totalQuantity = 0
            var overflow = false
            
            for row in productRows {
                
                let result = totalQuantity.addingReportingOverflow(
                    row.quantity
                )
                
                if result.overflow {
                    overflow = true
                    break
                }
                
                totalQuantity = result.partialValue
            }
            
            if overflow {
                skipped.append(
                    "\(name) — слишком большое количество"
                )
                continue
            }
            
            let addition = products[index].stock.addingReportingOverflow(
                totalQuantity
            )
            
            if addition.overflow {
                skipped.append(
                    "\(name) — слишком большое количество"
                )
                continue
            }
            
            products[index].stock = addition.partialValue
            
            added.append(
                "\(name) — добавлено \(totalQuantity)"
            )
        }
        
        // Создаём историю
        
        let entry = IncomingHistoryEntry(
            added: added,
            skipped: skipped
        )
        
        var newHistory = history
        newHistory.append(entry)
        
        guard let catalogData = try? JSONEncoder().encode(products) else {
            status = "Ошибка подготовки каталога"
            return
        }
        
        guard let historyData = try? JSONEncoder().encode(newHistory) else {
            status = "Ошибка подготовки истории"
            return
        }
        
        // Сохраняем каталог
        
        if !added.isEmpty {
            UserDefaults.standard.set(
                catalogData,
                forKey: storageKey
            )
        }
        
        // Сохраняем историю
        
        history = newHistory
        
        UserDefaults.standard.set(
            historyData,
            forKey: historyKey
        )
        
        // Запоминаем подтверждённые названия
        
        learnAliases()
        
        // Формируем отчёт
        
        var report = "Приход завершён!"
        
        if !added.isEmpty {
            report += "\n\nДобавлено на склад:\n"
            report += added.joined(separator: "\n")
        }
        
        if !skipped.isEmpty {
            report += "\n\nПропущено:\n"
            report += skipped.joined(separator: "\n")
        }
        
        status = report
        prepared = false
    }
    
    // MARK: - Отдельная строка товара
    
    private func incomingRowView(
        _ row: Binding<IncomingRow>
    ) -> some View {
        
        VStack(alignment: .leading, spacing: 8) {
            
            Text(row.wrappedValue.productName)
                .font(.headline)
            
            Text(
                "Количество: \(row.wrappedValue.quantity) шт."
            )
            
            if !row.wrappedValue.selectedName.isEmpty {
                
                Text(
                    "Найдено: \(row.wrappedValue.selectedName)"
                )
                .foregroundColor(.green)
                
            } else if !row.wrappedValue.candidates.isEmpty {
                
                Text("Выбери подходящий товар:")
                    .foregroundColor(.orange)
                
                Picker(
                    "Выбрать товар",
                    selection: row.selectedName
                ) {
                    
                    Text("Выбери товар")
                        .tag("")
                    
                    ForEach(
                        row.wrappedValue.candidates,
                        id: \.self
                    ) { candidate in
                        
                        Text(candidate)
                            .tag(candidate)
                    }
                }
                
            } else {
                
                Text("Совпадений по 3 буквам не найдено")
                    .foregroundColor(.red)
            }
        }
        .padding(.vertical, 5)
    }
    
    // MARK: - Блок ввода списка
    
    private var inputSection: some View {
        
        VStack(spacing: 12) {
            
            Button("Вставить из буфера") {
                
                if let text = UIPasteboard.general.string {
                    importedText = text
                    prepared = false
                    status = "Список вставлен"
                } else {
                    status = "Буфер обмена пуст"
                }
            }
            .buttonStyle(.borderedProminent)
            
            Text(status)
                .frame(
                    maxWidth: .infinity,
                    alignment: .leading
                )
            
            TextEditor(text: $importedText)
                .frame(height: 180)
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(Color.gray.opacity(0.3))
                )
            
            Button("Распознать товары") {
                prepareImport()
            }
            .buttonStyle(.borderedProminent)
        }
    }
    
    // MARK: - Блок распознанных товаров
    
    private var preparedSection: some View {
        
        Group {
            
            if prepared {
                
                List {
                    
                    ForEach($rows) { row in
                        incomingRowView(row)
                    }
                }
                .frame(minHeight: 120, maxHeight: 300)
                
                Button("Оприходовать товар") {
                    applyIncoming()
                }
                .buttonStyle(.borderedProminent)
                .disabled(
                    rows.isEmpty ||
                    rows.contains {
                        $0.selectedName.isEmpty ||
                        $0.candidates.isEmpty
                    }
                )
            }
        }
    }
    
    // MARK: - Одна запись истории
    
    private func historyRow(
        _ entry: IncomingHistoryEntry
    ) -> some View {
        
        Button {
            selectedHistoryEntry = entry
        } label: {
            
            VStack(
                alignment: .leading,
                spacing: 8
            ) {
                
                Text(
                    entry.date.formatted(
                        date: .numeric,
                        time: .shortened
                    )
                )
                .font(.headline)
                
                Text(
                    "Добавлено: \(entry.added.count) позиций"
                )
                .foregroundColor(.green)
                
                Text(
                    "Пропущено: \(entry.skipped.count) позиций"
                )
                .foregroundColor(.red)
                
                HStack {
                    Spacer()
                    
                    Text("Открыть подробности")
                        .font(.caption)
                        .foregroundColor(.blue)
                }
            }
            .padding(.vertical, 5)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .swipeActions(
            edge: .trailing,
            allowsFullSwipe: false
        ) {
            
            Button(role: .destructive) {
                deleteHistoryEntry(entry)
            } label: {
                Label(
                    "Удалить",
                    systemImage: "trash"
                )
            }
        }
    }
    
    // MARK: - Блок истории
    
    private var historySection: some View {
        
        VStack(alignment: .leading, spacing: 8) {
            
            Divider()
            
            Text("История прихода")
                .font(.title2)
                .frame(
                    maxWidth: .infinity,
                    alignment: .leading
                )
            
            if history.isEmpty {
                
                Text("Пока приходов нет")
                    .foregroundColor(.secondary)
                
            } else {
                
                List {
                    
                    ForEach(Array(history.reversed())) { entry in
                        historyRow(entry)
                    }
                }
                .frame(minHeight: 100, maxHeight: 250)
            }
        }
    }
    
    // MARK: - Главный интерфейс
    
    var body: some View {
        
        VStack(spacing: 12) {
            
            Text("Приход товара")
                .font(.title)
            
            inputSection
            
            preparedSection
            
            historySection
        }
        .padding()
        .onAppear {
            loadHistory()
            loadLearnedAliases()
        }
        .sheet(item: $selectedHistoryEntry) { entry in
            IncomingHistoryDetailView(entry: entry)
        }
    }
}
