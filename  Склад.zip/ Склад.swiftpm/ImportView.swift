
import SwiftUI
import UIKit

// MARK: - Модель истории

struct OrderHistoryEntry: Identifiable, Codable {
    var id = UUID()
    var date = Date()
    var deducted: [String]
    var skipped: [String]
}

// MARK: - Модель строки заявки

struct ImportRow: Identifiable {
    let id = UUID()
    let originalLine: String
    let productName: String
    let quantity: Int
    var candidates: [String]
    var selectedName: String
}

// MARK: - Подробности заявки

struct HistoryDetailView: View {
    
    let entry: OrderHistoryEntry
    
    var body: some View {
        
        NavigationStack {
            
            List {
                
                Section("Информация о заявке") {
                    Text(
                        entry.date.formatted(
                            date: .complete,
                            time: .shortened
                        )
                    )
                }
                
                Section("Списано") {
                    
                    if entry.deducted.isEmpty {
                        Text("Нет списанных товаров")
                            .foregroundColor(.secondary)
                    } else {
                        ForEach(entry.deducted, id: \.self) { item in
                            Text(item)
                                .foregroundColor(.green)
                        }
                    }
                }
                
                Section("Пропущено") {
                    
                    if entry.skipped.isEmpty {
                        Text("Нет пропущенных товаров")
                            .foregroundColor(.secondary)
                    } else {
                        ForEach(entry.skipped, id: \.self) { item in
                            Text(item)
                                .foregroundColor(.red)
                        }
                    }
                }
            }
            .navigationTitle("Заявка")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

// MARK: - Импорт заявки

struct ImportView: View {
    
    private let storageKey = "savedBeerCatalog"
    private let historyKey = "savedOrderHistory"
    private let learnedAliasesKey = "learnedBeerAliases"
    
    @State private var importedText = ""
    @State private var status = "Вставь заявку из буфера"
    @State private var rows: [ImportRow] = []
    @State private var prepared = false
    @State private var history: [OrderHistoryEntry] = []
    @State private var selectedHistoryEntry: OrderHistoryEntry?
    
    @State private var learnedAliases: [String: String] = [:]
    
    private let aliases: [String: String] = [
        "сухум нф": "Сухумское НФ.",
        "сухум св": "Сухумское св.",
        "лагерь св": "Лагер св.",
        "лагер св": "Лагер св.",
        "лагерь нф": "Лагер НФ.",
        "лагер нф": "Лагер НФ.",
        "фирменное св": "Фирменное св.",
        "фирменное нф": "Фирменное НФ.",
        "танк нф": "Танковое НФ.",
        "танк св": "Танковое св.",
        "чех св": "Чех св.",
        "чех нф": "Чех НФ.",
        "перворечка св": "Первореченское св.",
        "перворечка нф": "Первореченское НФ.",
        "первореченское св": "Первореченское св.",
        "первореченское нф": "Первореченское НФ.",
        "краснодар св": "Краснодарское св.",
        "краснодар нф": "Краснодарское НФ."
    ]
    
    // MARK: - Нормализация
    
    private func normalize(_ text: String) -> String {
        
        let folded = text.folding(
            options: [.caseInsensitive, .diacriticInsensitive],
            locale: Locale(identifier: "ru_RU")
        )
        
        let allowed = folded.map {
            $0.isLetter || $0.isNumber ? $0 : " "
        }
        
        return String(allowed)
            .split(whereSeparator: { $0.isWhitespace })
            .joined(separator: " ")
    }
    
    // MARK: - Поиск совпадающих букв
    
    // Ищет самую длинную последовательность
    // одинаковых букв в двух названиях
    
    private func longestCommonSubstring(
        _ first: String,
        _ second: String
    ) -> Int {
        
        let a = Array(normalize(first))
        let b = Array(normalize(second))
        
        guard !a.isEmpty, !b.isEmpty else {
            return 0
        }
        
        var previous = Array(
            repeating: 0,
            count: b.count + 1
        )
        
        var best = 0
        
        for i in 1...a.count {
            
            var current = Array(
                repeating: 0,
                count: b.count + 1
            )
            
            for j in 1...b.count {
                
                if a[i - 1] == b[j - 1] {
                    
                    current[j] = previous[j - 1] + 1
                    
                    best = max(
                        best,
                        current[j]
                    )
                }
            }
            
            previous = current
        }
        
        return best
    }
    
    // MARK: - Сохранение запомненных названий
    
    private func saveLearnedAliases() {
        
        UserDefaults.standard.set(
            learnedAliases,
            forKey: learnedAliasesKey
        )
    }
    
    // MARK: - Загрузка запомненных названий
    
    private func loadLearnedAliases() {
        
        guard let saved = UserDefaults.standard.dictionary(
            forKey: learnedAliasesKey
        ) as? [String: String] else {
            
            learnedAliases = [:]
            return
        }
        
        learnedAliases = saved
    }
    
    // MARK: - Поиск товара
    
    private func findCandidates(
        for name: String,
        products: [CatalogProduct]
    ) -> (candidates: [String], autoSelect: Bool) {
        
        let search = normalize(name)
        
        // 1. Проверяем запомненные названия
        
        if let learnedTarget = learnedAliases[search] {
            
            let matches = products.filter {
                normalize($0.name) == normalize(learnedTarget)
            }
            
            if let match = matches.first {
                return ([match.name], true)
            }
        }
        
        // 2. Проверяем встроенные сокращения
        
        let normalizedAliases = Dictionary(
            uniqueKeysWithValues: aliases.map {
                (normalize($0.key), normalize($0.value))
            }
        )
        
        if let aliasTarget = normalizedAliases[search] {
            
            let matches = products.filter {
                normalize($0.name) == aliasTarget
            }
            
            if let match = matches.first {
                return ([match.name], true)
            }
        }
        
        // 3. Если написано просто «Сухумское»,
        // предлагаем все его варианты
        
        if search == "сухумское" || search == "сухум" {
            
            let matches = products.filter {
                normalize($0.name).hasPrefix("сухумское")
            }
            
            return (
                matches.map { $0.name },
                false
            )
        }
        
        // 4. Проверяем точное совпадение
        
        if let exact = products.first(where: {
            normalize($0.name) == search
        }) {
            
            return ([exact.name], true)
        }
        
        // 5. Ищем похожие названия.
        // Минимум 3 одинаковые последовательные буквы.
        
        let scoredProducts = products.compactMap {
            product -> (name: String, score: Int)? in
            
            let score = longestCommonSubstring(
                search,
                product.name
            )
            
            guard score >= 3 else {
                return nil
            }
            
            return (
                name: product.name,
                score: score
            )
        }
        
        let sortedProducts = scoredProducts.sorted {
            $0.score > $1.score
        }
        
        return (
            sortedProducts.map { $0.name },
            false
        )
    }
    
    // MARK: - Загрузка каталога
    
    private func loadProducts() -> [CatalogProduct]? {
        
        guard let data = UserDefaults.standard.data(
            forKey: storageKey
        ),
              let products = try? JSONDecoder().decode(
                [CatalogProduct].self,
                from: data
              ) else {
            return nil
        }
        
        return products
    }
    
    // MARK: - Загрузка истории
    
    private func loadHistory() {
        
        guard let data = UserDefaults.standard.data(
            forKey: historyKey
        ),
              let savedHistory = try? JSONDecoder().decode(
                [OrderHistoryEntry].self,
                from: data
              ) else {
            
            history = []
            return
        }
        
        history = savedHistory
    }
    
    // MARK: - Удаление заявки из истории
    
    private func deleteHistoryEntry(
        _ entry: OrderHistoryEntry
    ) {
        
        history.removeAll {
            $0.id == entry.id
        }
        
        guard let data = try? JSONEncoder().encode(history) else {
            status = "Ошибка сохранения истории"
            return
        }
        
        UserDefaults.standard.set(
            data,
            forKey: historyKey
        )
    }
    
    // MARK: - Распознавание заявки
    
    private func prepareImport() {
        
        guard let products = loadProducts() else {
            status = "Не удалось загрузить каталог"
            return
        }
        
        var newRows: [ImportRow] = []
        
        for line in importedText.components(
            separatedBy: .newlines
        ) {
            
            let trimmed = line.trimmingCharacters(
                in: .whitespacesAndNewlines
            )
            
            guard trimmed.hasPrefix("- [x]") ||
                    trimmed.hasPrefix("- [X]") else {
                continue
            }
            
            let content = String(trimmed.dropFirst(5))
                .trimmingCharacters(
                    in: .whitespacesAndNewlines
                )
            
            let parts = content.split(
                whereSeparator: { $0.isWhitespace }
            )
            
            guard let last = parts.last,
                  let quantity = Int(last),
                  quantity > 0 else {
                continue
            }
            
            let name = parts.dropLast().joined(
                separator: " "
            )
            
            guard !name.isEmpty else {
                continue
            }
            
            let result = findCandidates(
                for: name,
                products: products
            )
            
            let selected = result.autoSelect &&
            result.candidates.count == 1
            ? result.candidates[0] : ""
            
            newRows.append(
                ImportRow(
                    originalLine: line,
                    productName: name,
                    quantity: quantity,
                    candidates: result.candidates,
                    selectedName: selected
                )
            )
        }
        
        rows = newRows
        prepared = true
        
        if rows.isEmpty {
            status = "Отмеченных товаров не найдено"
        } else {
            status = "Найдено товаров: \(rows.count)"
        }
    }
    
    // MARK: - Обучение новым названиям
    
    private func learnAliases() {
        
        let builtInNames = aliases.keys.map {
            normalize($0)
        }
        
        for row in rows {
            
            let search = normalize(row.productName)
            let selected = row.selectedName
            
            guard !search.isEmpty,
                  !selected.isEmpty,
                  search != normalize(selected) else {
                continue
            }
            
            // Не перезаписываем встроенные сокращения
            
            guard !builtInNames.contains(search) else {
                continue
            }
            
            // Запоминаем соответствие
            
            learnedAliases[search] = selected
        }
        
        saveLearnedAliases()
    }
    
    // MARK: - Списание
    
    private func applyImport() {
        
        guard var products = loadProducts() else {
            status = "Ошибка загрузки каталога"
            return
        }
        
        // Проверяем, что все товары подтверждены
        
        guard !rows.isEmpty,
              !rows.contains(where: {
                  $0.selectedName.isEmpty ||
                  $0.candidates.isEmpty
              }) else {
            
            status = "Сначала выбери все товары"
            return
        }
        
        let groupedRows = Dictionary(
            grouping: rows,
            by: { $0.selectedName }
        )
        
        var deducted: [String] = []
        var skipped: [String] = []
        
        for (name, productRows) in groupedRows {
            
            guard !name.isEmpty,
                  let index = products.firstIndex(where: {
                      $0.name == name
                  }) else {
                
                let displayName =
                productRows.first?.productName ?? name
                
                skipped.append(
                    "\(displayName) — товар не найден"
                )
                
                continue
            }
            
            let totalQuantity = productRows.reduce(0) {
                $0 + $1.quantity
            }
            
            if products[index].stock >= totalQuantity {
                
                products[index].stock -= totalQuantity
                
                deducted.append(
                    "\(name) — списано \(totalQuantity)"
                )
                
            } else {
                
                skipped.append(
                    "\(name) — нужно \(totalQuantity), остаток \(products[index].stock)"
                )
            }
        }
        
        // Сохраняем каталог
        
        if !deducted.isEmpty {
            
            guard let data = try? JSONEncoder().encode(products) else {
                status = "Ошибка сохранения каталога"
                return
            }
            
            UserDefaults.standard.set(
                data,
                forKey: storageKey
            )
        }
        
        // Запоминаем новые названия после подтверждения выбора
        
        learnAliases()
        
        // Сохраняем историю
        
        let entry = OrderHistoryEntry(
            deducted: deducted,
            skipped: skipped
        )
        
        history.append(entry)
        
        guard let historyData = try? JSONEncoder().encode(history) else {
            status = "Ошибка сохранения истории"
            return
        }
        
        UserDefaults.standard.set(
            historyData,
            forKey: historyKey
        )
        
        var report = "Списание завершено!"
        
        if !deducted.isEmpty {
            report += "\n\nСписано:\n"
            report += deducted.joined(separator: "\n")
        }
        
        if !skipped.isEmpty {
            report += "\n\nПропущено:\n"
            report += skipped.joined(separator: "\n")
        }
        
        status = report
        prepared = false
    }
    
    // MARK: - Интерфейс
    
    var body: some View {
        
        VStack(spacing: 12) {
            
            Text("Импорт заявки")
                .font(.title)
            
            Button("Вставить из буфера") {
                
                if let text = UIPasteboard.general.string {
                    importedText = text
                    prepared = false
                    status = "Заявка вставлена"
                } else {
                    status = "Буфер обмена пуст"
                }
            }
            .buttonStyle(.borderedProminent)
            
            Text(status)
                .frame(
                    maxWidth: .infinity,
                    alignment: .leading
                )
            
            TextEditor(text: $importedText)
                .frame(height: 180)
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(Color.gray.opacity(0.3))
                )
            
            Button("Распознать товары") {
                prepareImport()
            }
            .buttonStyle(.borderedProminent)
            
            if prepared {
                
                List {
                    ForEach($rows) { $row in
                        
                        VStack(
                            alignment: .leading,
                            spacing: 8
                        ) {
                            
                            Text(row.productName)
                                .font(.headline)
                            
                            Text(
                                "Количество: \(row.quantity) шт."
                            )
                            
                            if !row.selectedName.isEmpty {
                                
                                Text(
                                    "Найдено: \(row.selectedName)"
                                )
                                .foregroundColor(.green)
                                
                            } else if !row.candidates.isEmpty {
                                
                                Text(
                                    "Выбери подходящий товар:"
                                )
                                .foregroundColor(.orange)
                                
                                Picker(
                                    "Выбрать товар",
                                    selection: $row.selectedName
                                ) {
                                    
                                    Text("Выбери товар")
                                        .tag("")
                                    
                                    ForEach(
                                        row.candidates,
                                        id: \.self
                                    ) { candidate in
                                        
                                        Text(candidate)
                                            .tag(candidate)
                                    }
                                }
                                
                            } else {
                                
                                Text(
                                    "Совпадений по 3 буквам не найдено"
                                )
                                .foregroundColor(.red)
                            }
                        }
                        .padding(.vertical, 5)
                    }
                }
                
                Button("Списать остатки") {
                    applyImport()
                }
                .buttonStyle(.borderedProminent)
                .disabled(
                    rows.isEmpty ||
                    rows.contains {
                        $0.selectedName.isEmpty ||
                        $0.candidates.isEmpty
                    }
                )
            }
            
            Divider()
            
            Text("История заявок")
                .font(.title2)
                .frame(
                    maxWidth: .infinity,
                    alignment: .leading
                )
            
            if history.isEmpty {
                
                Text("Пока заявок нет")
                    .foregroundColor(.secondary)
                
            } else {
                
                List {
                    ForEach(history.reversed()) { entry in
                        
                        Button {
                            selectedHistoryEntry = entry
                        } label: {
                            
                            VStack(
                                alignment: .leading,
                                spacing: 8
                            ) {
                                
                                Text(
                                    entry.date.formatted(
                                        date: .numeric,
                                        time: .shortened
                                    )
                                )
                                .font(.headline)
                                
                                Text(
                                    "Списано: \(entry.deducted.count) позиций"
                                )
                                .foregroundColor(.green)
                                
                                Text(
                                    "Пропущено: \(entry.skipped.count) позиций"
                                )
                                .foregroundColor(.red)
                                
                                HStack {
                                    Spacer()
                                    
                                    Text("Открыть подробности")
                                        .font(.caption)
                                        .foregroundColor(.blue)
                                }
                            }
                            .padding(.vertical, 5)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        .swipeActions(
                            edge: .trailing,
                            allowsFullSwipe: false
                        ) {
                            
                            Button(
                                role: .destructive
                            ) {
                                deleteHistoryEntry(entry)
                            } label: {
                                Label(
                                    "Удалить",
                                    systemImage: "trash"
                                )
                            }
                        }
                    }
                }
            }
        }
        .padding()
        .onAppear {
            loadHistory()
            loadLearnedAliases()
        }
        .sheet(item: $selectedHistoryEntry) { entry in
            HistoryDetailView(entry: entry)
        }
    }
}
