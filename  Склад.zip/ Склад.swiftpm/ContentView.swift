
import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.13, green: 0.14, blue: 0.16)
                    .ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 30) {
                        
                        VStack(spacing: 5) {
                            Text("BAVARSKI")
                                .font(.system(size: 42, weight: .black))
                                .tracking(4)
                                .foregroundColor(.orange)
                            
                            Text("СКЛАД")
                                .font(.system(size: 23, weight: .bold))
                                .tracking(5)
                                .foregroundColor(.white)
                        }
                        .padding(.vertical, 22)
                        .frame(maxWidth: .infinity)
                        .background(
                            RoundedRectangle(cornerRadius: 20)
                                .fill(Color.white.opacity(0.05))
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 20)
                                .stroke(Color.orange, lineWidth: 2)
                        )
                        .shadow(color: .orange.opacity(0.2), radius: 12)
                        
                        Text("Управление складом")
                            .font(.headline)
                            .foregroundColor(.white.opacity(0.7))
                        
                        VStack(spacing: 18) {
                            
                            NavigationLink {
                                ImportView()
                            } label: {
                                menuButton(
                                    title: "Импорт заявки",
                                    subtitle: "Списание товара",
                                    icon: "tray.and.arrow.down.fill",
                                    colors: [.blue, .indigo]
                                )
                            }
                            .buttonStyle(AnimatedMenuButtonStyle())
                            
                            NavigationLink {
                                CreateOrderView()
                            } label: {
                                menuButton(
                                    title: "Создать заявку",
                                    subtitle: "Новая заявка для магазина",
                                    icon: "doc.badge.plus",
                                    colors: [.purple, .indigo]
                                )
                            }
                            .buttonStyle(AnimatedMenuButtonStyle())
                            
                            NavigationLink {
                                IncomingView()
                            } label: {
                                menuButton(
                                    title: "Приход товара",
                                    subtitle: "Пополнение склада",
                                    icon: "tray.and.arrow.up.fill",
                                    colors: [.green, .teal]
                                )
                            }
                            .buttonStyle(AnimatedMenuButtonStyle())
                            
                            NavigationLink {
                                CatalogView()
                            } label: {
                                menuButton(
                                    title: "Каталог товаров",
                                    subtitle: "Остатки и управление",
                                    icon: "list.bullet.rectangle.fill",
                                    colors: [.orange, .red]
                                )
                            }
                            .buttonStyle(AnimatedMenuButtonStyle())
                        }
                    }
                    .padding(20)
                    .frame(maxWidth: 550)
                    .frame(maxWidth: .infinity)
                }
            }
            .toolbar(.hidden, for: .navigationBar)
        }
    }
    
    func menuButton(
        title: String,
        subtitle: String,
        icon: String,
        colors: [Color]
    ) -> some View {
        HStack(spacing: 16) {
            Image(systemName: icon)
                .font(.system(size: 30))
                .frame(width: 45)
            
            VStack(alignment: .leading, spacing: 5) {
                Text(title)
                    .font(.system(size: 19, weight: .bold))
                
                Text(subtitle)
                    .font(.system(size: 13))
                    .opacity(0.85)
            }
            
            Spacer()
            
            Image(systemName: "chevron.right")
                .font(.system(size: 14, weight: .bold))
        }
        .foregroundColor(.white)
        .padding(18)
        .frame(maxWidth: .infinity, minHeight: 88)
        .background(
            LinearGradient(
                colors: colors,
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay(
            RoundedRectangle(cornerRadius: 18)
                .stroke(Color.white.opacity(0.2), lineWidth: 1)
        )
        .shadow(color: colors[0].opacity(0.3), radius: 7, y: 4)
    }
}

struct AnimatedMenuButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0)
            .opacity(configuration.isPressed ? 0.85 : 1.0)
            .animation(
                .spring(response: 0.25, dampingFraction: 0.55),
                value: configuration.isPressed
            )
    }
}
