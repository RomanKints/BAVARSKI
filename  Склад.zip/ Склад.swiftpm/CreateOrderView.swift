
import SwiftUI
import UIKit

// MARK: - Модель строки заявки

struct CreateOrderRow: Identifiable, Codable, Equatable {
    var id = UUID()
    var productName: String
    var quantity: Int
    var candidates: [String]
    var selectedName: String
    var isTaken: Bool
}

// MARK: - Старая модель черновика

private struct CreateOrderDraft: Codable {
    var selectedShop: String
    var importedText: String
    var rows: [CreateOrderRow]
}

// MARK: - Модель ожидающей заявки

private struct PendingShopOrder: Identifiable, Codable {
    var id = UUID()
    var date = Date()
    var shop: String
    var importedText: String
    var rows: [CreateOrderRow]
}

// MARK: - Модель истории

struct ShipmentHistoryEntry: Identifiable, Codable {
    var id = UUID()
    var date = Date()
    var shop: String
    var status: String
    var items: [String]
}

// MARK: - Экран заявок

struct CreateOrderView: View {
    
    private let storageKey = "savedBeerCatalog"
    private let historyKey = "savedShipmentHistory"
    private let oldDraftKey = "savedCreateOrderDraft"
    private let pendingOrdersKey = "savedPendingShopOrders"
    
    private let shops = ["БАВ 1", "БАВ 2", "БАВ 3"]
    
    @State private var selectedShop = "БАВ 1"
    
    // Открытая заявка
    
    @State private var editorOrderID: UUID?
    @State private var importedText = ""
    @State private var rows: [CreateOrderRow] = []
    
    @State private var status = "Введи товары и количество"
    
    // Очередь заявок
    
    @State private var pendingOrders: [PendingShopOrder] = []
    
    // История
    
    @State private var history: [ShipmentHistoryEntry] = []
    
    // Состояния
    
    @State private var isShipping = false
    @State private var showingShipmentConfirmation = false
    
    @State private var showingAlert = false
    @State private var alertMessage = ""
    
    @State private var showingPendingDeleteConfirmation = false
    @State private var pendingOrderToDeleteID: UUID?
    
    @State private var showingHistoryDeleteConfirmation = false
    @State private var historyEntryToDeleteID: UUID?
    
    @State private var showingClearHistoryConfirmation = false
    
    // MARK: - Вспомогательные данные
    
    private func ordersForShop(_ shop: String) -> [PendingShopOrder] {
        pendingOrders
            .filter { $0.shop == shop }
            .sorted { $0.date > $1.date }
    }
    
    private var sortedHistory: [ShipmentHistoryEntry] {
        history.sorted { $0.date > $1.date }
    }
    
    private var currentEditingOrder: PendingShopOrder? {
        guard let id = editorOrderID else {
            return nil
        }
        
        return pendingOrders.first {
            $0.id == id
        }
    }
    
    // Проверка: открыт ли редактор именно этого магазина
    
    private func isEditingShop(_ shop: String) -> Bool {
        currentEditingOrder?.shop == shop
    }
    
    // MARK: - Сохранение очереди
    
    private func savePendingOrders() -> Bool {
        
        guard let data = try? JSONEncoder().encode(pendingOrders) else {
            return false
        }
        
        UserDefaults.standard.set(
            data,
            forKey: pendingOrdersKey
        )
        
        return true
    }
    
    // MARK: - Загрузка очереди и перенос старого черновика
    
    private func loadPendingOrders() {
        
        let defaults = UserDefaults.standard
        
        if let data = defaults.data(forKey: pendingOrdersKey) {
            
            guard let saved = try? JSONDecoder().decode(
                [PendingShopOrder].self,
                from: data
            ) else {
                
                alertMessage = "Не удалось прочитать сохранённые заявки. Данные не удалены."
                showingAlert = true
                return
            }
            
            pendingOrders = saved
            return
        }
        
        guard let oldData = defaults.data(forKey: oldDraftKey) else {
            pendingOrders = []
            return
        }
        
        guard let oldDraft = try? JSONDecoder().decode(
            CreateOrderDraft.self,
            from: oldData
        ) else {
            
            alertMessage = "Не удалось перенести старый черновик. Исходные данные сохранены."
            showingAlert = true
            return
        }
        
        let shop = shops.contains(oldDraft.selectedShop)
        ? oldDraft.selectedShop
        : shops[0]
        
        let migratedOrder = PendingShopOrder(
            shop: shop,
            importedText: oldDraft.importedText,
            rows: oldDraft.rows
        )
        
        pendingOrders = [migratedOrder]
        
        if savePendingOrders() {
            defaults.removeObject(forKey: oldDraftKey)
        } else {
            
            pendingOrders = []
            
            alertMessage = "Не удалось перенести старую заявку. Старый черновик сохранён."
            showingAlert = true
        }
    }
    
    // MARK: - Сохранение открытой заявки
    
    private func saveCurrentOrder() {
        
        guard let orderID = editorOrderID,
              let index = pendingOrders.firstIndex(where: {
                  $0.id == orderID
              }) else {
            return
        }
        
        pendingOrders[index].importedText = importedText
        pendingOrders[index].rows = rows
        
        _ = savePendingOrders()
    }
    
    // MARK: - Создание новой заявки
    
    private func createNewOrder(for shop: String) {
        
        saveCurrentOrder()
        
        selectedShop = shop
        
        let order = PendingShopOrder(
            shop: shop,
            importedText: "",
            rows: []
        )
        
        pendingOrders.append(order)
        
        guard savePendingOrders() else {
            
            pendingOrders.removeAll {
                $0.id == order.id
            }
            
            alertMessage = "Не удалось сохранить новую заявку"
            showingAlert = true
            return
        }
        
        editorOrderID = order.id
        importedText = ""
        rows = []
        
        status = "Введи товары и количество"
    }
    
    // MARK: - Открытие заявки
    
    private func openOrder(_ order: PendingShopOrder) {
        
        saveCurrentOrder()
        
        editorOrderID = order.id
        selectedShop = order.shop
        
        importedText = order.importedText
        rows = order.rows
        
        status = rows.isEmpty
        ? "Заявка открыта. Можно продолжить ввод"
        : "Заявка восстановлена. Позиций: \(rows.count)"
    }
    
    // MARK: - Закрытие редактора
    
    private func closeEditor() {
        
        saveCurrentOrder()
        
        editorOrderID = nil
        importedText = ""
        rows = []
        
        status = "Выбери заявку или создай новую"
    }
    
    // MARK: - Удаление ожидающей заявки
    
    private func deletePendingOrder() {
        
        guard let id = pendingOrderToDeleteID else {
            return
        }
        
        let oldOrders = pendingOrders
        
        pendingOrders.removeAll {
            $0.id == id
        }
        
        guard savePendingOrders() else {
            
            pendingOrders = oldOrders
            
            alertMessage = "Не удалось удалить заявку"
            showingAlert = true
            return
        }
        
        if editorOrderID == id {
            editorOrderID = nil
            importedText = ""
            rows = []
        }
        
        pendingOrderToDeleteID = nil
    }
    
    // MARK: - Нормализация названий
    
    private func normalize(_ text: String) -> String {
        
        let folded = text.folding(
            options: [.caseInsensitive, .diacriticInsensitive],
            locale: Locale(identifier: "ru_RU")
        )
        
        let allowed = folded.map {
            $0.isLetter || $0.isNumber ? $0 : " "
        }
        
        return String(allowed)
            .split(whereSeparator: { $0.isWhitespace })
            .joined(separator: " ")
    }
    
    // MARK: - Поиск похожих товаров
    
    private func longestCommonSubstring(
        _ first: String,
        _ second: String
    ) -> Int {
        
        let a = Array(normalize(first))
        let b = Array(normalize(second))
        
        guard !a.isEmpty, !b.isEmpty else {
            return 0
        }
        
        var previous = Array(
            repeating: 0,
            count: b.count + 1
        )
        
        var best = 0
        
        for i in 1...a.count {
            
            var current = Array(
                repeating: 0,
                count: b.count + 1
            )
            
            for j in 1...b.count {
                
                if a[i - 1] == b[j - 1] {
                    
                    current[j] = previous[j - 1] + 1
                    best = max(best, current[j])
                }
            }
            
            previous = current
        }
        
        return best
    }
    
    // MARK: - Поиск товара в каталоге
    
    private func findProduct(
        _ name: String,
        products: [CatalogProduct]
    ) -> (names: [String], selected: String) {
        
        let search = normalize(name)
        
        if let exact = products.first(where: {
            normalize($0.name) == search
        }) {
            return ([exact.name], exact.name)
        }
        
        let aliases: [String: String] = [
            
            "сухум нф": "Сухумское НФ.",
            "сухум св": "Сухумское св.",
            
            "лагерь св": "Лагер св.",
            "лагер св": "Лагер св.",
            
            "лагерь нф": "Лагер НФ.",
            "лагер нф": "Лагер НФ.",
            
            "фирменное св": "Фирменное св.",
            "фирменное нф": "Фирменное НФ.",
            
            "танк нф": "Танковое НФ.",
            "танк св": "Танковое св.",
            
            "чех св": "Чех св.",
            "чех нф": "Чех НФ.",
            
            "перворечка св": "Первореченское св.",
            "перворечка нф": "Первореченское НФ.",
            
            "первореченское св": "Первореченское св.",
            "первореченское нф": "Первореченское НФ.",
            
            "краснодар св": "Краснодарское св.",
            "краснодар нф": "Краснодарское НФ."
        ]
        
        if let target = aliases[search] {
            
            if let product = products.first(where: {
                normalize($0.name) == normalize(target)
            }) {
                return ([product.name], product.name)
            }
        }
        
        if search == "сухум" || search == "сухумское" {
            
            let matches = products.filter {
                normalize($0.name).hasPrefix("сухумское")
            }
            
            return (
                matches.map { $0.name },
                ""
            )
        }
        
        var scored: [(name: String, score: Int)] = []
        
        for product in products {
            
            let score = longestCommonSubstring(
                search,
                product.name
            )
            
            if score >= 3 {
                scored.append((product.name, score))
            }
        }
        
        scored.sort {
            $0.score > $1.score
        }
        
        return (
            scored.map { $0.name },
            ""
        )
    }
    
    // MARK: - Загрузка каталога
    
    private func loadProducts() -> [CatalogProduct]? {
        
        guard let data = UserDefaults.standard.data(
            forKey: storageKey
        ) else {
            return nil
        }
        
        return try? JSONDecoder().decode(
            [CatalogProduct].self,
            from: data
        )
    }
    
    // MARK: - Загрузка истории
    
    private func loadHistory() {
        
        guard let data = UserDefaults.standard.data(
            forKey: historyKey
        ) else {
            
            history = []
            return
        }
        
        guard let saved = try? JSONDecoder().decode(
            [ShipmentHistoryEntry].self,
            from: data
        ) else {
            
            alertMessage = "Не удалось прочитать историю отгрузок. Данные не удалены."
            showingAlert = true
            return
        }
        
        history = saved
    }
    
    // MARK: - Сохранение истории
    
    private func saveHistory() -> Bool {
        
        guard let data = try? JSONEncoder().encode(history) else {
            return false
        }
        
        UserDefaults.standard.set(
            data,
            forKey: historyKey
        )
        
        return true
    }
    
    // MARK: - Распознавание заявки
    
    private func prepareOrder() {
        
        guard editorOrderID != nil else {
            return
        }
        
        guard let products = loadProducts() else {
            
            status = "Ошибка загрузки каталога"
            return
        }
        
        var newRows: [CreateOrderRow] = []
        
        for line in importedText.components(
            separatedBy: .newlines
        ) {
            
            let content = line.trimmingCharacters(
                in: .whitespacesAndNewlines
            )
            
            if content.isEmpty {
                continue
            }
            
            let parts = content.split(
                whereSeparator: { $0.isWhitespace }
            )
            
            guard let last = parts.last,
                  let quantity = Int(last),
                  quantity > 0 else {
                continue
            }
            
            let name = parts.dropLast().joined(
                separator: " "
            )
            
            guard !name.isEmpty else {
                continue
            }
            
            let result = findProduct(
                name,
                products: products
            )
            
            newRows.append(
                CreateOrderRow(
                    productName: name,
                    quantity: quantity,
                    candidates: result.names,
                    selectedName: result.selected,
                    isTaken: false
                )
            )
        }
        
        rows = newRows
        
        if rows.isEmpty {
            status = "Товары не распознаны. Проверь названия и количество"
        } else {
            status = "Распознано позиций: \(rows.count)"
        }
        
        saveCurrentOrder()
    }
    
    // MARK: - Копирование заявки
    
    private func copyOrder() {
        
        guard !rows.isEmpty else {
            
            status = "Сначала создай заявку"
            return
        }
        
        let shop = currentEditorShop()
        
        var text = "ЗАЯВКА — \(shop)\n\n"
        
        for row in rows {
            
            let name = row.selectedName.isEmpty
            ? row.productName
            : row.selectedName
            
            let mark = row.isTaken ? "☑" : "☐"
            
            text += "\(mark) \(name) \(row.quantity)\n"
        }
        
        UIPasteboard.general.string = text
        
        status = "Вся заявка скопирована"
    }
    
    // MARK: - Магазин открытой заявки
    
    private func currentEditorShop() -> String {
        
        guard let id = editorOrderID,
              let order = pendingOrders.first(where: {
                  $0.id == id
              }) else {
            return selectedShop
        }
        
        return order.shop
    }
    
    // MARK: - Отгрузка
    
    private func applyShipment() {
        
        guard !isShipping else {
            return
        }
        
        guard let orderID = editorOrderID,
              let orderIndex = pendingOrders.firstIndex(where: {
                  $0.id == orderID
              }) else {
            
            alertMessage = "Заявка не найдена"
            showingAlert = true
            return
        }
        
        let orderShop = pendingOrders[orderIndex].shop
        
        isShipping = true
        
        defer {
            isShipping = false
        }
        
        guard var products = loadProducts() else {
            
            alertMessage = "Не удалось загрузить каталог"
            showingAlert = true
            return
        }
        
        let selectedRows = rows.filter {
            $0.isTaken
        }
        
        guard !selectedRows.isEmpty else {
            
            alertMessage = "Не отмечено ни одного товара"
            showingAlert = true
            return
        }
        
        // Проверка распознавания
        
        for row in selectedRows {
            
            guard !row.selectedName.isEmpty,
                  row.candidates.contains(row.selectedName) else {
                
                alertMessage = "Сначала выбери правильный товар для всех отмеченных позиций"
                showingAlert = true
                return
            }
        }
        
        // Объединение одинаковых товаров
        
        var totals: [String: Int] = [:]
        
        for row in selectedRows {
            
            let result = totals[row.selectedName, default: 0]
                .addingReportingOverflow(row.quantity)
            
            guard !result.overflow else {
                
                alertMessage = "Слишком большое количество"
                showingAlert = true
                return
            }
            
            totals[row.selectedName] = result.partialValue
        }
        
        // Проверка остатков
        
        for (name, quantity) in totals {
            
            guard let product = products.first(where: {
                $0.name == name
            }) else {
                
                alertMessage = "Товар \(name) отсутствует в каталоге"
                showingAlert = true
                return
            }
            
            if product.stock < quantity {
                
                alertMessage =
                "\(name)\nНужно: \(quantity)\nНа складе: \(product.stock)"
                
                showingAlert = true
                return
            }
        }
        
        // Списание товаров
        
        for (name, quantity) in totals {
            
            guard let index = products.firstIndex(where: {
                $0.name == name
            }) else {
                
                alertMessage = "Не удалось найти товар \(name)"
                showingAlert = true
                return
            }
            
            products[index].stock -= quantity
        }
        
        // Формирование истории
        
        var items: [String] = []
        
        for row in rows {
            
            let name = row.selectedName.isEmpty
            ? row.productName
            : row.selectedName
            
            let mark = row.isTaken
            ? "Отгружено"
            : "Не отгружено"
            
            items.append(
                "\(mark): \(name) — \(row.quantity)"
            )
        }
        
        let entry = ShipmentHistoryEntry(
            shop: orderShop,
            status: "Отгружено",
            items: items
        )
        
        var updatedHistory = history
        updatedHistory.append(entry)
        
        // Удаление только конкретной заявки
        
        var updatedPendingOrders = pendingOrders
        
        updatedPendingOrders.removeAll {
            $0.id == orderID
        }
        
        guard let catalogData = try? JSONEncoder().encode(products) else {
            
            alertMessage = "Не удалось подготовить данные каталога"
            showingAlert = true
            return
        }
        
        guard let historyData = try? JSONEncoder().encode(updatedHistory) else {
            
            alertMessage = "Не удалось подготовить историю отгрузок"
            showingAlert = true
            return
        }
        
        guard let pendingData = try? JSONEncoder().encode(updatedPendingOrders) else {
            
            alertMessage = "Не удалось подготовить очередь заявок"
            showingAlert = true
            return
        }
        
        // Сохранение
        
        let defaults = UserDefaults.standard
        
        defaults.set(catalogData, forKey: storageKey)
        defaults.set(historyData, forKey: historyKey)
        defaults.set(pendingData, forKey: pendingOrdersKey)
        
        // Обновление интерфейса
        
        pendingOrders = updatedPendingOrders
        history = updatedHistory
        
        editorOrderID = nil
        importedText = ""
        rows = []
        
        status = "Отгрузка успешно завершена!"
    }
    
    // MARK: - Строка товара
    
    private func orderRow(
        _ row: Binding<CreateOrderRow>
    ) -> some View {
        
        VStack(alignment: .leading, spacing: 10) {
            
            Button {
                
                row.isTaken.wrappedValue.toggle()
                
            } label: {
                
                HStack(alignment: .center, spacing: 12) {
                    
                    Image(
                        systemName: row.wrappedValue.isTaken
                        ? "checkmark.square.fill"
                        : "square"
                    )
                    .font(.title2)
                    .foregroundColor(
                        row.wrappedValue.isTaken ? .green : .secondary
                    )
                    
                    Text(
                        row.wrappedValue.selectedName.isEmpty
                        ? row.wrappedValue.productName
                        : row.wrappedValue.selectedName
                    )
                    .font(.system(size: 19, weight: .semibold))
                    .foregroundColor(.primary)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
                    
                    Spacer(minLength: 8)
                    
                    Text("\(row.wrappedValue.quantity)")
                        .font(.system(size: 19, weight: .bold))
                        .foregroundColor(.primary)
                        .fixedSize()
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            
            if row.wrappedValue.candidates.isEmpty {
                
                Text("Товар не найден в каталоге")
                    .foregroundColor(.red)
                    .font(.caption)
                
            } else if row.wrappedValue.selectedName.isEmpty {
                
                Picker(
                    "Выбрать товар",
                    selection: row.selectedName
                ) {
                    
                    Text("Выбери товар")
                        .tag("")
                    
                    ForEach(
                        row.wrappedValue.candidates,
                        id: \.self
                    ) { candidate in
                        
                        Text(candidate)
                            .tag(candidate)
                    }
                }
                .tint(.orange)
            }
        }
        .padding(.vertical, 7)
    }
    
    // MARK: - Карточка ожидающей заявки
    
    private func pendingOrderView(
        _ order: PendingShopOrder
    ) -> some View {
        
        VStack(alignment: .leading, spacing: 10) {
            
            HStack {
                
                VStack(alignment: .leading, spacing: 5) {
                    
                    Text(
                        "Заявка · \(order.date.formatted(date: .numeric, time: .shortened))"
                    )
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    
                    Text("Позиций: \(order.rows.count)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                Button {
                    
                    pendingOrderToDeleteID = order.id
                    showingPendingDeleteConfirmation = true
                    
                } label: {
                    
                    Image(systemName: "trash")
                        .font(.body)
                        .foregroundColor(.red)
                        .padding(8)
                        .background(Color.red.opacity(0.08))
                        .clipShape(Circle())
                }
                .buttonStyle(.plain)
            }
            
            Button {
                
                openOrder(order)
                
            } label: {
                
                HStack {
                    
                    Label(
                        "Открыть заявку",
                        systemImage: "doc.text"
                    )
                    .font(.subheadline)
                    .fontWeight(.medium)
                    
                    Spacer()
                    
                    Image(systemName: "chevron.right")
                        .font(.caption)
                }
                .padding(.vertical, 11)
                .padding(.horizontal, 13)
                .background(Color.orange.opacity(0.12))
                .clipShape(RoundedRectangle(cornerRadius: 10))
            }
            .buttonStyle(.plain)
            .foregroundColor(.primary)
        }
        .padding(12)
        .background(Color.gray.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
    
    // MARK: - Блок отдельного магазина
    
    private func shopSection(_ shop: String) -> some View {
        
        let shopOrders = ordersForShop(shop)
        
        return VStack(alignment: .leading, spacing: 14) {
            
            // Заголовок магазина
            
            HStack(spacing: 12) {
                
                Image(systemName: "storefront.fill")
                    .font(.title2)
                    .foregroundColor(.orange)
                    .frame(width: 42, height: 42)
                    .background(Color.orange.opacity(0.12))
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                
                VStack(alignment: .leading, spacing: 3) {
                    
                    Text(shop)
                        .font(.title3)
                        .fontWeight(.bold)
                    
                    Text(
                        shopOrders.isEmpty
                        ? "Нет ожидающих заявок"
                        : "Ожидает отгрузки: \(shopOrders.count)"
                    )
                    .font(.caption)
                    .foregroundColor(.secondary)
                }
                
                Spacer()
                
                Text("\(shopOrders.count)")
                    .font(.headline)
                    .fontWeight(.bold)
                    .foregroundColor(
                        shopOrders.isEmpty ? .secondary : .orange
                    )
                    .frame(width: 36, height: 36)
                    .background(
                        shopOrders.isEmpty
                        ? Color.gray.opacity(0.10)
                        : Color.orange.opacity(0.12)
                    )
                    .clipShape(Circle())
            }
            
            // РЕДАКТОР СРАЗУ ПОД НАЗВАНИЕМ МАГАЗИНА
            
            if isEditingShop(shop) {
                editorSection
            }
            
            Divider()
            
            // Список заявок магазина
            
            if shopOrders.isEmpty {
                
                VStack(spacing: 7) {
                    
                    Image(systemName: "tray")
                        .font(.title2)
                        .foregroundColor(.secondary)
                    
                    Text("Заявок пока нет")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                
            } else {
                
                ForEach(shopOrders) { order in
                    pendingOrderView(order)
                }
            }
            
            // Создание заявки именно для этого магазина
            
            Button {
                
                createNewOrder(for: shop)
                
            } label: {
                
                HStack {
                    
                    Image(systemName: "plus.circle.fill")
                    
                    Text("Создать новую заявку")
                    
                    Spacer()
                    
                    Image(systemName: "arrow.right")
                        .font(.caption)
                }
                .font(.subheadline)
                .fontWeight(.semibold)
                .padding(.horizontal, 14)
                .padding(.vertical, 13)
                .frame(maxWidth: .infinity)
                .background(Color.orange)
                .foregroundColor(.white)
                .clipShape(RoundedRectangle(cornerRadius: 11))
            }
            .buttonStyle(.plain)
        }
        .padding(15)
        .background(Color.gray.opacity(0.07))
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color.gray.opacity(0.15), lineWidth: 1)
        )
    }
    
    // MARK: - Редактор заявки
    
    @ViewBuilder
    private var editorSection: some View {
        
        if let currentOrder = currentEditingOrder {
            
            VStack(alignment: .leading, spacing: 14) {
                
                HStack {
                    
                    VStack(alignment: .leading, spacing: 5) {
                        
                        Text("Редактирование заявки")
                            .font(.headline)
                        
                        HStack(spacing: 6) {
                            
                            Image(systemName: "storefront")
                                .foregroundColor(.orange)
                            
                            Text(currentOrder.shop)
                                .foregroundColor(.secondary)
                        }
                        .font(.subheadline)
                    }
                    
                    Spacer()
                    
                    Button("Закрыть") {
                        closeEditor()
                    }
                    .font(.subheadline)
                }
                
                Divider()
                
                Text("Введи товары и количество")
                    .font(.subheadline)
                    .fontWeight(.medium)
                
                TextEditor(text: $importedText)
                    .frame(height: 140)
                    .padding(5)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.gray.opacity(0.3))
                    )
                
                Button {
                    
                    prepareOrder()
                    
                } label: {
                    
                    Label(
                        "Распознать заявку",
                        systemImage: "text.magnifyingglass"
                    )
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                
                Text(status)
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                if !rows.isEmpty {
                    recognizedRowsSection
                }
            }
            .padding(15)
            .background(Color.orange.opacity(0.06))
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .overlay(
                RoundedRectangle(cornerRadius: 16)
                    .stroke(Color.orange.opacity(0.2), lineWidth: 1)
            )
        }
    }
    
    // MARK: - Распознанные позиции
    
    private var recognizedRowsSection: some View {
        
        VStack(spacing: 10) {
            
            Text("Список товаров")
                .font(.headline)
                .frame(
                    maxWidth: .infinity,
                    alignment: .leading
                )
            
            ForEach($rows) { row in
                
                orderRow(row)
                
                Divider()
            }
            
            Button {
                
                copyOrder()
                
            } label: {
                
                Label(
                    "Скопировать всю заявку",
                    systemImage: "doc.on.doc"
                )
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(.bordered)
            
            Button {
                
                showingShipmentConfirmation = true
                
            } label: {
                
                Label(
                    isShipping ? "Отгрузка..." : "Отгрузить",
                    systemImage: "shippingbox.fill"
                )
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .tint(.green)
            .disabled(isShipping)
        }
        .padding(13)
        .background(Color.gray.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
    
    // MARK: - История одной отгрузки
    
    private func shipmentHistoryView(
        _ entry: ShipmentHistoryEntry
    ) -> some View {
        
        VStack(alignment: .leading, spacing: 10) {
            
            HStack {
                
                VStack(alignment: .leading, spacing: 4) {
                    
                    Text(entry.shop)
                        .font(.headline)
                    
                    Text(
                        entry.date.formatted(
                            date: .numeric,
                            time: .shortened
                        )
                    )
                    .font(.caption)
                    .foregroundColor(.secondary)
                }
                
                Spacer()
                
                Text(entry.status)
                    .font(.caption)
                    .foregroundColor(.green)
                    .padding(.horizontal, 9)
                    .padding(.vertical, 5)
                    .background(Color.green.opacity(0.12))
                    .clipShape(Capsule())
                
                Button {
                    
                    historyEntryToDeleteID = entry.id
                    showingHistoryDeleteConfirmation = true
                    
                } label: {
                    
                    Image(systemName: "trash")
                        .foregroundColor(.red)
                        .padding(8)
                }
                .buttonStyle(.plain)
            }
            
            Divider()
            
            ForEach(
                Array(entry.items.enumerated()),
                id: \.offset
            ) { _, item in
                
                HStack(alignment: .top, spacing: 8) {
                    
                    Image(
                        systemName: item.hasPrefix("Отгружено")
                        ? "checkmark.circle.fill"
                        : "circle"
                    )
                    .foregroundColor(
                        item.hasPrefix("Отгружено")
                        ? .green
                        : .secondary
                    )
                    
                    Text(item)
                        .font(.subheadline)
                        .foregroundColor(.primary)
                }
            }
        }
        .padding()
        .background(Color.gray.opacity(0.07))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
    
    // MARK: - Блок истории
    
    private var historySection: some View {
        
        VStack(alignment: .leading, spacing: 13) {
            
            HStack {
                
                Image(systemName: "clock.arrow.circlepath")
                    .foregroundColor(.orange)
                
                Text("История отгрузок")
                    .font(.title3)
                    .fontWeight(.bold)
                
                Spacer()
                
                Text("\(history.count)")
                    .font(.caption)
                    .fontWeight(.bold)
                    .foregroundColor(.secondary)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .background(Color.gray.opacity(0.12))
                    .clipShape(Capsule())
            }
            
            if history.isEmpty {
                
                Text("Отгрузок пока нет")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 18)
                
            } else {
                
                Button(role: .destructive) {
                    
                    showingClearHistoryConfirmation = true
                    
                } label: {
                    
                    Label(
                        "Очистить всю историю",
                        systemImage: "trash"
                    )
                    .font(.subheadline)
                }
                .frame(
                    maxWidth: .infinity,
                    alignment: .trailing
                )
                
                ForEach(sortedHistory) { entry in
                    shipmentHistoryView(entry)
                }
            }
        }
        .padding(15)
        .background(Color.gray.opacity(0.06))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
    
    // MARK: - Удаление одной записи истории
    
    private func deleteHistoryEntry() {
        
        guard let id = historyEntryToDeleteID else {
            return
        }
        
        let oldHistory = history
        
        history.removeAll {
            $0.id == id
        }
        
        guard saveHistory() else {
            
            history = oldHistory
            
            alertMessage = "Не удалось удалить запись истории"
            showingAlert = true
            return
        }
        
        historyEntryToDeleteID = nil
    }
    
    // MARK: - Очистка истории
    
    private func clearHistory() {
        
        let oldHistory = history
        
        history = []
        
        guard saveHistory() else {
            
            history = oldHistory
            
            alertMessage = "Не удалось очистить историю"
            showingAlert = true
            return
        }
    }
    
    // MARK: - Главный интерфейс
    
    var body: some View {
        
        ScrollView {
            
            VStack(spacing: 18) {
                
                // Заголовок
                
                VStack(alignment: .leading, spacing: 5) {
                    
                    Text("Заявки магазинов")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                    
                    Text("Выбери магазин, чтобы создать или открыть заявку")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                .frame(
                    maxWidth: .infinity,
                    alignment: .leading
                )
                .padding(.bottom, 4)
                
                // Три независимых блока магазинов
                
                ForEach(shops, id: \.self) { shop in
                    shopSection(shop)
                }
                
                Divider()
                    .padding(.vertical, 4)
                
                // История
                
                historySection
            }
            .padding()
        }
        .navigationTitle("Создать заявку")
        .navigationBarTitleDisplayMode(.inline)
        
        // Загрузка данных
        
        .onAppear {
            
            loadHistory()
            loadPendingOrders()
        }
        
        // Автосохранение редактора
        
        .onChange(of: importedText) { _ in
            saveCurrentOrder()
        }
        
        .onChange(of: rows) { _ in
            saveCurrentOrder()
        }
        
        // Подтверждение отгрузки
        
        .confirmationDialog(
            "Отгрузить товары для \(currentEditorShop())?",
            isPresented: $showingShipmentConfirmation,
            titleVisibility: .visible
        ) {
            
            Button(
                "Подтвердить отгрузку",
                role: .destructive
            ) {
                
                DispatchQueue.main.async {
                    applyShipment()
                }
            }
            
            Button("Отмена", role: .cancel) { }
        }
        
        // Подтверждение удаления заявки
        
        .confirmationDialog(
            "Удалить эту ожидающую заявку?",
            isPresented: $showingPendingDeleteConfirmation,
            titleVisibility: .visible
        ) {
            
            Button("Удалить заявку", role: .destructive) {
                deletePendingOrder()
            }
            
            Button("Отмена", role: .cancel) { }
        }
        
        // Подтверждение удаления записи истории
        
        .confirmationDialog(
            "Удалить эту запись из истории?",
            isPresented: $showingHistoryDeleteConfirmation,
            titleVisibility: .visible
        ) {
            
            Button("Удалить запись", role: .destructive) {
                deleteHistoryEntry()
            }
            
            Button("Отмена", role: .cancel) { }
        }
        
        // Подтверждение очистки истории
        
        .confirmationDialog(
            "Удалить всю историю отгрузок?",
            isPresented: $showingClearHistoryConfirmation,
            titleVisibility: .visible
        ) {
            
            Button("Удалить всю историю", role: .destructive) {
                clearHistory()
            }
            
            Button("Отмена", role: .cancel) { }
        }
        
        // Информационные сообщения
        
        .alert(
            "Информация",
            isPresented: $showingAlert
        ) {
            
            Button("Понятно", role: .cancel) { }
            
        } message: {
            
            Text(alertMessage)
        }
    }
}
