BAVARSKI PWA — обновление v23

Файлы:
index.html — интерфейс
app.js — складская логика и данные
manifest.webmanifest — установка на экран Домой
aicon.svg — значок
sw.js — офлайн-кэш

Размещение:
Содержимое папки BAVARSKI-PWA нужно разместить в корне GitHub Pages сайта.
GitHub Pages: Settings → Pages → Build and deployment → GitHub Actions.

После публикации открыть адрес сайта в Safari на iPhone → Поделиться → На экран «Домой».

Данные сохраняются в IndexedDB и резервной копии localStorage. Экспорт JSON находится в разделе «Ещё».
